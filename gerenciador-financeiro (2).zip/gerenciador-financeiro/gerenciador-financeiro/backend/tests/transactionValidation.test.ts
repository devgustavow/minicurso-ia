import { describe, expect, it } from 'vitest';
import { validateNewTransaction } from '../src/services/transactionValidation.js';

const valid = {
  type: 'income',
  description: '  Salário de outubro  ',
  amountCents: 350000,
  category: 'Salário',
  date: '2026-10-05',
};

function errorsFor(overrides: Record<string, unknown>) {
  const result = validateNewTransaction({ ...valid, ...overrides });
  return result.ok ? {} : result.errors;
}

describe('validateNewTransaction', () => {
  it('TU-01: aceita entrada válida e remove espaços da descrição', () => {
    expect(validateNewTransaction(valid)).toEqual({
      ok: true,
      value: { ...valid, description: 'Salário de outubro' },
    });
  });

  it('TU-02: rejeita cada campo ausente com erro no próprio campo', () => {
    const result = validateNewTransaction({});
    expect(result).toEqual({
      ok: false,
      errors: {
        type: 'Informe o tipo.',
        description: 'Informe a descrição.',
        amountCents: 'Informe o valor.',
        category: 'Informe a categoria.',
        date: 'Informe a data.',
      },
    });
  });

  it('TU-02: trata corpo nulo ou não objeto como campos ausentes', () => {
    expect(validateNewTransaction(null).ok).toBe(false);
    expect(validateNewTransaction('texto').ok).toBe(false);
  });

  it.each([0, -1, -0.5])('TU-03: rejeita valor %s', (amountCents) => {
    expect(errorsFor({ amountCents })).toEqual({ amountCents: 'Informe um valor maior que zero.' });
  });

  it('TU-04: rejeita valor não inteiro, texto e acima do máximo', () => {
    expect(errorsFor({ amountCents: 10.5 }).amountCents).toBe('O valor deve ser informado em centavos inteiros.');
    expect(errorsFor({ amountCents: '100' }).amountCents).toBe('Informe um valor numérico.');
    expect(errorsFor({ amountCents: Number.NaN }).amountCents).toBe('Informe um valor numérico.');
    expect(errorsFor({ amountCents: 10_000_000_000 }).amountCents).toBe('O valor máximo é R$ 99.999.999,99.');
    expect(errorsFor({ amountCents: 9_999_999_999 })).toEqual({});
    expect(errorsFor({ amountCents: 1 })).toEqual({});
  });

  it('TU-05: rejeita descrição vazia, só com espaços, não texto e longa demais', () => {
    expect(errorsFor({ description: '' }).description).toBe('Informe a descrição.');
    expect(errorsFor({ description: '    ' }).description).toBe('Informe a descrição.');
    expect(errorsFor({ description: 42 }).description).toBe('Informe a descrição.');
    expect(errorsFor({ description: 'a'.repeat(121) }).description).toBe('A descrição deve ter no máximo 120 caracteres.');
    expect(errorsFor({ description: 'a'.repeat(120) })).toEqual({});
  });

  it.each(['2026-02-31', '2026-13-01', '2026-00-10', '2025-02-29', '05/10/2026', '2026-1-5', 20261005])(
    'TU-06: rejeita data %s',
    (date) => {
      expect(errorsFor({ date })).toEqual({ date: 'Informe uma data válida.' });
    },
  );

  it('TU-06: aceita 29 de fevereiro em ano bissexto', () => {
    expect(errorsFor({ date: '2028-02-29' })).toEqual({});
  });

  it('TU-07: rejeita tipo e categoria fora da lista', () => {
    expect(errorsFor({ type: 'transfer' })).toEqual({ type: 'Tipo inválido. Use receita ou despesa.' });
    expect(errorsFor({ category: 'Viagem' })).toEqual({ category: 'Categoria inválida.' });
  });
});
