import { describe, expect, it } from 'vitest';
import { loadConfig } from '../src/config.js';

describe('loadConfig', () => {
  it('usa valores padrão quando as variáveis não existem', () => {
    expect(loadConfig({})).toEqual({
      port: 3000,
      dbPath: './data/finance.db',
      logLevel: 'info',
      shutdownTimeoutMs: 10000,
    });
  });

  it('lê os valores informados', () => {
    const config = loadConfig({ PORT: '3050', DB_PATH: '/tmp/x.db', LOG_LEVEL: 'debug', SHUTDOWN_TIMEOUT_MS: '500' });
    expect(config).toEqual({ port: 3050, dbPath: '/tmp/x.db', logLevel: 'debug', shutdownTimeoutMs: 500 });
  });

  it('rejeita número inválido', () => {
    expect(() => loadConfig({ PORT: 'abc' })).toThrow('PORT');
  });
});
