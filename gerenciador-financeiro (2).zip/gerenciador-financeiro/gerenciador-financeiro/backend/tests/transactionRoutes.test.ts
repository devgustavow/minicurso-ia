import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import request from 'supertest';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../src/app.js';
import { openDatabase, type Database } from '../src/data/database.js';
import { createTransactionRepository } from '../src/data/transactionRepository.js';
import { createTransactionRouter } from '../src/routes/transactionRoutes.js';
import { createTransactionService } from '../src/services/transactionService.js';

const valid = { type: 'income', description: 'Salário', amountCents: 350000, category: 'Salário', date: '2026-10-05' };

describe('rotas de lançamentos', () => {
  let dir: string;
  let db: Database;
  let app: ReturnType<typeof createApp>;

  beforeEach(() => {
    dir = mkdtempSync(join(tmpdir(), 'api-'));
    db = openDatabase(join(dir, 'finance.db'));
    app = createApp({ routers: [createTransactionRouter(createTransactionService(createTransactionRepository(db)))] });
  });

  afterEach(() => {
    db.close();
    rmSync(dir, { recursive: true, force: true });
  });

  const post = (body: unknown) => request(app).post('/api/transactions').send(body as object);
  const month = (value?: string) => request(app).get('/api/transactions').query(value ? { month: value } : {});

  it('TI-01: POST válido retorna 201 com o lançamento e o persiste', async () => {
    const response = await post(valid);
    expect(response.status).toBe(201);
    expect(response.body).toMatchObject({ id: 1, ...valid });
    const listed = await month('2026-10');
    expect(listed.body.transactions).toHaveLength(1);
  });

  it.each([
    ['campos vazios', { type: '', description: '', amountCents: '', category: '', date: '' }, ['type', 'description', 'amountCents', 'category', 'date']],
    ['valor zero', { ...valid, amountCents: 0 }, ['amountCents']],
    ['valor negativo', { ...valid, amountCents: -100 }, ['amountCents']],
    ['valor decimal', { ...valid, amountCents: 10.5 }, ['amountCents']],
    ['data inexistente', { ...valid, date: '2026-02-31' }, ['date']],
    ['categoria inválida', { ...valid, category: 'Viagem' }, ['category']],
    ['descrição longa', { ...valid, description: 'x'.repeat(121) }, ['description']],
  ])('TI-02: rejeita %s com 400 padronizado e não grava', async (_name, body, fields) => {
    const response = await post(body);
    expect(response.status).toBe(400);
    expect(response.body.error.code).toBe('VALIDATION_ERROR');
    expect(Object.keys(response.body.error.details).sort()).toEqual([...fields].sort());
    const listed = await month('2026-10');
    expect(listed.body.transactions).toEqual([]);
  });

  it('TI-03: retorna apenas o mês pedido em ordem date DESC, id DESC', async () => {
    await post({ ...valid, description: 'set', date: '2026-09-30' });
    await post({ ...valid, description: 'a', date: '2026-10-03' });
    await post({ ...valid, description: 'b', date: '2026-10-31' });
    await post({ ...valid, description: 'c', date: '2026-10-03' });
    await post({ ...valid, description: 'nov', date: '2026-11-01' });
    const response = await month('2026-10');
    expect(response.status).toBe(200);
    expect(response.body.transactions.map((t: { description: string }) => t.description)).toEqual(['b', 'c', 'a']);
  });

  it('TI-04: resumo exato com decimais e saldo negativo', async () => {
    await post({ ...valid, amountCents: 10 });
    await post({ ...valid, amountCents: 20 });
    expect((await month('2026-10')).body.summary).toEqual({ incomeCents: 30, expenseCents: 0, balanceCents: 30 });
    await post({ ...valid, type: 'expense', category: 'Moradia', amountCents: 5030 });
    expect((await month('2026-10')).body.summary).toEqual({ incomeCents: 30, expenseCents: 5030, balanceCents: -5000 });
  });

  it('TI-05: mês vazio retorna lista vazia e resumo zerado', async () => {
    const response = await month('2030-01');
    expect(response.body).toEqual({
      month: '2030-01',
      transactions: [],
      summary: { incomeCents: 0, expenseCents: 0, balanceCents: 0 },
    });
  });

  it.each([undefined, '2026-13', 'outubro', '2026-1'])('TI-06: month %s retorna 400 INVALID_MONTH', async (value) => {
    const response = await month(value);
    expect(response.status).toBe(400);
    expect(response.body.error.code).toBe('INVALID_MONTH');
  });

  it('TI-06: month repetido na query é rejeitado', async () => {
    const response = await request(app).get('/api/transactions?month=2026-10&month=2026-11');
    expect(response.status).toBe(400);
  });
});
