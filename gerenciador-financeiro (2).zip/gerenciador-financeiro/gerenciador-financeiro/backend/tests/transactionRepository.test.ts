import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { openDatabase, type Database } from '../src/data/database.js';
import { createTransactionRepository } from '../src/data/transactionRepository.js';
import type { NewTransaction } from '../src/types/transaction.js';

const OCTOBER = { start: '2026-10-01', endExclusive: '2026-11-01' };

function tx(overrides: Partial<NewTransaction> = {}): NewTransaction {
  return { type: 'expense', description: 'Mercado', amountCents: 1000, category: 'Alimentação', date: '2026-10-10', ...overrides };
}

describe('transactionRepository', () => {
  let dir: string;
  let dbPath: string;
  let db: Database;

  beforeEach(() => {
    dir = mkdtempSync(join(tmpdir(), 'repo-'));
    dbPath = join(dir, 'nested', 'finance.db');
    db = openDatabase(dbPath);
  });

  afterEach(() => {
    if (db.isOpen) db.close();
    rmSync(dir, { recursive: true, force: true });
  });

  it('insere e devolve o lançamento com id e createdAt', () => {
    const created = createTransactionRepository(db).insert(tx());
    expect(created).toMatchObject({ id: 1, ...tx() });
    expect(created.createdAt).toMatch(/^\d{4}-\d{2}-\d{2}T/);
  });

  it('busca apenas o período, ordenado por data e id decrescentes', () => {
    const repo = createTransactionRepository(db);
    repo.insert(tx({ description: 'setembro', date: '2026-09-30' }));
    repo.insert(tx({ description: 'a', date: '2026-10-05' }));
    repo.insert(tx({ description: 'b', date: '2026-10-20' }));
    repo.insert(tx({ description: 'c', date: '2026-10-05' }));
    repo.insert(tx({ description: 'novembro', date: '2026-11-01' }));
    expect(repo.findByPeriod(OCTOBER).map((t) => t.description)).toEqual(['b', 'c', 'a']);
  });

  it('soma receitas e despesas em centavos inteiros', () => {
    const repo = createTransactionRepository(db);
    repo.insert(tx({ type: 'income', amountCents: 10 }));
    repo.insert(tx({ type: 'income', amountCents: 20 }));
    repo.insert(tx({ type: 'expense', amountCents: 5 }));
    expect(repo.sumByPeriod(OCTOBER)).toEqual({ incomeCents: 30, expenseCents: 5 });
    expect(repo.sumByPeriod({ start: '2026-01-01', endExclusive: '2026-02-01' })).toEqual({ incomeCents: 0, expenseCents: 0 });
  });

  it('trata dados com aspas e SQL como texto (queries parametrizadas)', () => {
    const repo = createTransactionRepository(db);
    const description = "x'); DROP TABLE transactions; --";
    repo.insert(tx({ description }));
    expect(repo.findByPeriod(OCTOBER)[0]?.description).toBe(description);
  });

  it('TI-07: mantém os lançamentos ao fechar e reabrir o banco no mesmo arquivo', () => {
    createTransactionRepository(db).insert(tx({ description: 'persistente', amountCents: 4321 }));
    db.close();
    db = openDatabase(dbPath);
    const [found] = createTransactionRepository(db).findByPeriod(OCTOBER);
    expect(found).toMatchObject({ description: 'persistente', amountCents: 4321 });
  });

  it('TI-10: consulta um mês com 1.000 lançamentos em menos de 1 s', () => {
    const repo = createTransactionRepository(db);
    db.exec('BEGIN');
    for (let i = 0; i < 1000; i += 1) {
      repo.insert(tx({ amountCents: i + 1, date: `2026-10-${String((i % 28) + 1).padStart(2, '0')}` }));
    }
    db.exec('COMMIT');
    const started = performance.now();
    const rows = repo.findByPeriod(OCTOBER);
    const totals = repo.sumByPeriod(OCTOBER);
    expect(performance.now() - started).toBeLessThan(1000);
    expect(rows).toHaveLength(1000);
    expect(totals.expenseCents).toBe(500500);
  });

  it('aceita banco em memória', () => {
    const memory = openDatabase(':memory:');
    expect(createTransactionRepository(memory).findByPeriod(OCTOBER)).toEqual([]);
    memory.close();
  });
});
