import { describe, expect, it, vi } from 'vitest';
import type { TransactionRepository } from '../src/data/transactionRepository.js';
import { parseMonth } from '../src/services/month.js';
import { createTransactionService } from '../src/services/transactionService.js';

function fakeRepository(totals = { incomeCents: 0, expenseCents: 0 }): TransactionRepository {
  return {
    insert: vi.fn((data) => ({ ...data, id: 7, createdAt: '2026-10-15T00:00:00.000Z' })),
    findByPeriod: vi.fn(() => []),
    sumByPeriod: vi.fn(() => totals),
  };
}

describe('parseMonth', () => {
  it('TU-08: calcula o intervalo do mês', () => {
    expect(parseMonth('2026-10')).toEqual({ start: '2026-10-01', endExclusive: '2026-11-01' });
  });

  it('TU-08: dezembro termina em janeiro do ano seguinte', () => {
    expect(parseMonth('2026-12')).toEqual({ start: '2026-12-01', endExclusive: '2027-01-01' });
  });

  it.each(['2026-13', '2026-00', '2026-1', '10-2026', '', 202610, undefined])('TU-08: rejeita %s', (value) => {
    expect(parseMonth(value)).toBeNull();
  });
});

describe('transactionService', () => {
  it('TU-09: monta o resumo com saldo = receitas − despesas', () => {
    const repo = fakeRepository({ incomeCents: 30, expenseCents: 10 });
    const result = createTransactionService(repo).getMonthly('2026-10');
    expect(result).toEqual({
      ok: true,
      value: { month: '2026-10', transactions: [], summary: { incomeCents: 30, expenseCents: 10, balanceCents: 20 } },
    });
    expect(repo.findByPeriod).toHaveBeenCalledWith({ start: '2026-10-01', endExclusive: '2026-11-01' });
  });

  it('TU-09: saldo negativo quando despesas superam receitas', () => {
    const result = createTransactionService(fakeRepository({ incomeCents: 0, expenseCents: 5000 })).getMonthly('2026-10');
    expect(result.ok && result.value.summary.balanceCents).toBe(-5000);
  });

  it('rejeita mês inválido sem consultar o repositório', () => {
    const repo = fakeRepository();
    expect(createTransactionService(repo).getMonthly('outubro')).toEqual({
      ok: false,
      errors: { month: 'Informe o mês no formato AAAA-MM.' },
    });
    expect(repo.findByPeriod).not.toHaveBeenCalled();
  });

  it('cria lançamento válido e não grava inválido', () => {
    const repo = fakeRepository();
    const service = createTransactionService(repo);
    const input = { type: 'expense', description: 'Ônibus', amountCents: 450, category: 'Transporte', date: '2026-10-02' };
    expect(service.createTransaction(input)).toMatchObject({ ok: true, value: { id: 7, ...input } });
    expect(service.createTransaction({ ...input, amountCents: 0 }).ok).toBe(false);
    expect(repo.insert).toHaveBeenCalledOnce();
  });
});
