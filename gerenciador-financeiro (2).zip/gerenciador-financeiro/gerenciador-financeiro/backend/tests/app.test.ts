import { Router } from 'express';
import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../src/app.js';
import { HttpError } from '../src/routes/errors.js';

function appWithFailingRoutes() {
  const router = Router();
  router.get('/boom', () => {
    throw new Error('segredo interno');
  });
  router.get('/teapot', () => {
    throw new HttpError(418, 'TEAPOT', 'Sou um bule.');
  });
  router.post('/echo', (req, res) => {
    res.json(req.body);
  });
  return createApp({ routers: [router] });
}

describe('app', () => {
  it('responde ao health check', async () => {
    const response = await request(createApp()).get('/api/health');
    expect(response.status).toBe(200);
    expect(response.body).toEqual({ status: 'ok' });
  });

  it('TI-08: rota inexistente retorna 404 padronizado', async () => {
    const response = await request(createApp()).get('/api/nao-existe');
    expect(response.status).toBe(404);
    expect(response.body.error.code).toBe('NOT_FOUND');
  });

  it('TI-08: erro inesperado retorna 500 sem detalhes internos', async () => {
    const response = await request(appWithFailingRoutes()).get('/api/boom');
    expect(response.status).toBe(500);
    expect(response.body).toEqual({
      error: { code: 'INTERNAL_ERROR', message: 'Erro interno do servidor.' },
    });
    expect(JSON.stringify(response.body)).not.toContain('segredo');
  });

  it('TI-08: HttpError usa status e código próprios', async () => {
    const response = await request(appWithFailingRoutes()).get('/api/teapot');
    expect(response.status).toBe(418);
    expect(response.body.error).toMatchObject({ code: 'TEAPOT', message: 'Sou um bule.' });
  });

  it('TI-08: JSON malformado retorna 400 INVALID_JSON', async () => {
    const response = await request(appWithFailingRoutes())
      .post('/api/echo')
      .set('Content-Type', 'application/json')
      .send('{"invalido":');
    expect(response.status).toBe(400);
    expect(response.body.error.code).toBe('INVALID_JSON');
  });
});
