import { EventEmitter } from 'node:events';
import { createServer, type Server } from 'node:http';
import { describe, expect, it, vi } from 'vitest';
import { logger } from '../src/logger.js';
import { registerShutdown } from '../src/shutdown.js';

function listen(server: Server): Promise<void> {
  return new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
}

describe('registerShutdown', () => {
  it('TI-09: ao receber SIGTERM fecha o servidor, libera recursos e sai com 0', async () => {
    const server = createServer((_req, res) => res.end('ok'));
    await listen(server);
    const signals = new EventEmitter();
    const closeResources = vi.fn();
    const exited = new Promise<number>((resolve) => {
      registerShutdown({
        server,
        closeResources,
        timeoutMs: 5000,
        logger,
        exit: resolve,
        signalSource: signals,
      });
    });

    signals.emit('SIGTERM');

    expect(await exited).toBe(0);
    expect(closeResources).toHaveBeenCalledOnce();
    expect(server.listening).toBe(false);
  });

  it('TI-09: ignora sinais repetidos e força saída após o tempo limite', async () => {
    vi.useFakeTimers();
    const close = vi.fn();
    const server = { close, closeIdleConnections: vi.fn() } as unknown as Server;
    const signals = new EventEmitter();
    const exit = vi.fn();
    registerShutdown({ server, closeResources: vi.fn(), timeoutMs: 100, logger, exit, signalSource: signals });

    signals.emit('SIGINT');
    signals.emit('SIGINT');
    vi.advanceTimersByTime(150);

    expect(close).toHaveBeenCalledOnce();
    expect(exit).toHaveBeenCalledWith(1);
    vi.useRealTimers();
  });
});
