import type { Period } from '../types/transaction.js';

const MONTH_PATTERN = /^(\d{4})-(0[1-9]|1[0-2])$/;

function pad(value: number): string {
  return String(value).padStart(2, '0');
}

export function parseMonth(value: unknown): Period | null {
  if (typeof value !== 'string') {
    return null;
  }
  const match = MONTH_PATTERN.exec(value);
  if (!match) {
    return null;
  }
  const year = Number(match[1]);
  const month = Number(match[2]);
  const nextYear = month === 12 ? year + 1 : year;
  const nextMonth = month === 12 ? 1 : month + 1;
  return {
    start: `${year}-${pad(month)}-01`,
    endExclusive: `${nextYear}-${pad(nextMonth)}-01`,
  };
}
