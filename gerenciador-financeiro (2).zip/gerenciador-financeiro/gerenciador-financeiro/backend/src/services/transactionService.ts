import type { TransactionRepository } from '../data/transactionRepository.js';
import type { MonthlyReport, Transaction } from '../types/transaction.js';
import { fail, ok, type Result } from '../types/result.js';
import { parseMonth } from './month.js';
import { validateNewTransaction } from './transactionValidation.js';

export interface TransactionService {
  createTransaction(input: unknown): Result<Transaction>;
  getMonthly(month: unknown): Result<MonthlyReport>;
}

export function createTransactionService(repository: TransactionRepository): TransactionService {
  return {
    createTransaction(input) {
      const validation = validateNewTransaction(input);
      if (!validation.ok) {
        return validation;
      }
      return ok(repository.insert(validation.value));
    },
    getMonthly(month) {
      const period = parseMonth(month);
      if (!period) {
        return fail({ month: 'Informe o mês no formato AAAA-MM.' });
      }
      const totals = repository.sumByPeriod(period);
      return ok({
        month: month as string,
        transactions: repository.findByPeriod(period),
        summary: {
          incomeCents: totals.incomeCents,
          expenseCents: totals.expenseCents,
          balanceCents: totals.incomeCents - totals.expenseCents,
        },
      });
    },
  };
}
