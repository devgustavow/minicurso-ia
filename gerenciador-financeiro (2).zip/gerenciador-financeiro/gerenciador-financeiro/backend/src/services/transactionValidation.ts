import {
  CATEGORIES,
  MAX_AMOUNT_CENTS,
  MAX_DESCRIPTION_LENGTH,
  TRANSACTION_TYPES,
  type Category,
  type NewTransaction,
  type TransactionType,
} from '../types/transaction.js';
import { fail, ok, type FieldErrors, type Result } from '../types/result.js';

const DATE_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;

function isMissing(value: unknown): boolean {
  return value === undefined || value === null || value === '';
}

export function isValidCalendarDate(value: string): boolean {
  const match = DATE_PATTERN.exec(value);
  if (!match) {
    return false;
  }
  const [year, month, day] = [Number(match[1]), Number(match[2]), Number(match[3])];
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}

function checkType(value: unknown): string | undefined {
  if (isMissing(value)) return 'Informe o tipo.';
  if (!TRANSACTION_TYPES.includes(value as TransactionType)) return 'Tipo inválido. Use receita ou despesa.';
  return undefined;
}

function checkDescription(value: unknown): string | undefined {
  if (typeof value !== 'string' || value.trim() === '') return 'Informe a descrição.';
  if (value.trim().length > MAX_DESCRIPTION_LENGTH) {
    return `A descrição deve ter no máximo ${MAX_DESCRIPTION_LENGTH} caracteres.`;
  }
  return undefined;
}

function checkAmount(value: unknown): string | undefined {
  if (isMissing(value)) return 'Informe o valor.';
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'Informe um valor numérico.';
  if (value <= 0) return 'Informe um valor maior que zero.';
  if (!Number.isSafeInteger(value)) return 'O valor deve ser informado em centavos inteiros.';
  if (value > MAX_AMOUNT_CENTS) return 'O valor máximo é R$ 99.999.999,99.';
  return undefined;
}

function checkCategory(value: unknown): string | undefined {
  if (isMissing(value)) return 'Informe a categoria.';
  if (!CATEGORIES.includes(value as Category)) return 'Categoria inválida.';
  return undefined;
}

function checkDate(value: unknown): string | undefined {
  if (isMissing(value)) return 'Informe a data.';
  if (typeof value !== 'string' || !isValidCalendarDate(value)) return 'Informe uma data válida.';
  return undefined;
}

export function validateNewTransaction(input: unknown): Result<NewTransaction> {
  const data = (typeof input === 'object' && input !== null ? input : {}) as Record<string, unknown>;
  const checks: Record<keyof NewTransaction, string | undefined> = {
    type: checkType(data.type),
    description: checkDescription(data.description),
    amountCents: checkAmount(data.amountCents),
    category: checkCategory(data.category),
    date: checkDate(data.date),
  };
  const errors: FieldErrors = {};
  for (const [field, message] of Object.entries(checks)) {
    if (message) errors[field] = message;
  }
  if (Object.keys(errors).length > 0) {
    return fail(errors);
  }
  return ok({
    type: data.type as TransactionType,
    description: (data.description as string).trim(),
    amountCents: data.amountCents as number,
    category: data.category as Category,
    date: data.date as string,
  });
}
