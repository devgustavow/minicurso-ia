import { createApp } from './app.js';
import { config } from './config.js';
import { openDatabase } from './data/database.js';
import { createTransactionRepository } from './data/transactionRepository.js';
import { logger } from './logger.js';
import { createTransactionRouter } from './routes/transactionRoutes.js';
import { createTransactionService } from './services/transactionService.js';
import { registerShutdown } from './shutdown.js';

const db = openDatabase(config.dbPath);
const service = createTransactionService(createTransactionRepository(db));
const app = createApp({ routers: [createTransactionRouter(service)] });

const server = app.listen(config.port, () => {
  logger.info({ port: config.port, dbPath: config.dbPath }, 'Servidor iniciado');
});

registerShutdown({
  server,
  closeResources: () => db.close(),
  timeoutMs: config.shutdownTimeoutMs,
  logger,
});
