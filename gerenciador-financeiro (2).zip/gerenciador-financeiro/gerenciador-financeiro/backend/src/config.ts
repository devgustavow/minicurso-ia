import 'dotenv/config';

export interface AppConfig {
  port: number;
  dbPath: string;
  logLevel: string;
  shutdownTimeoutMs: number;
}

type Env = Record<string, string | undefined>;

function readInteger(env: Env, name: string, fallback: number): number {
  const raw = env[name];
  if (raw === undefined || raw === '') {
    return fallback;
  }
  const value = Number(raw);
  if (!Number.isInteger(value) || value < 0) {
    throw new Error(`Variável de ambiente ${name} inválida: ${raw}`);
  }
  return value;
}

export function loadConfig(env: Env): AppConfig {
  return {
    port: readInteger(env, 'PORT', 3000),
    dbPath: env.DB_PATH || './data/finance.db',
    logLevel: env.LOG_LEVEL || 'info',
    shutdownTimeoutMs: readInteger(env, 'SHUTDOWN_TIMEOUT_MS', 10000),
  };
}

export const config = loadConfig(process.env);
