import type { Database } from './database.js';
import type {
  Category,
  NewTransaction,
  Period,
  PeriodTotals,
  Transaction,
  TransactionType,
} from '../types/transaction.js';

interface TransactionRow {
  id: number;
  type: TransactionType;
  description: string;
  amount_cents: number;
  category: Category;
  date: string;
  created_at: string;
}

const SELECT_COLUMNS = 'id, type, description, amount_cents, category, date, created_at';

function toTransaction(row: TransactionRow): Transaction {
  return {
    id: row.id,
    type: row.type,
    description: row.description,
    amountCents: row.amount_cents,
    category: row.category,
    date: row.date,
    createdAt: row.created_at,
  };
}

export interface TransactionRepository {
  insert(data: NewTransaction): Transaction;
  findByPeriod(period: Period): Transaction[];
  sumByPeriod(period: Period): PeriodTotals;
}

export function createTransactionRepository(db: Database): TransactionRepository {
  const insertStmt = db.prepare(
    `INSERT INTO transactions (type, description, amount_cents, category, date)
     VALUES (?, ?, ?, ?, ?) RETURNING ${SELECT_COLUMNS}`,
  );
  const findStmt = db.prepare(
    `SELECT ${SELECT_COLUMNS} FROM transactions
     WHERE date >= ? AND date < ? ORDER BY date DESC, id DESC`,
  );
  const sumStmt = db.prepare(
    `SELECT
       COALESCE(SUM(CASE WHEN type = 'income' THEN amount_cents END), 0) AS income_cents,
       COALESCE(SUM(CASE WHEN type = 'expense' THEN amount_cents END), 0) AS expense_cents
     FROM transactions WHERE date >= ? AND date < ?`,
  );

  return {
    insert(data) {
      const row = insertStmt.get(data.type, data.description, data.amountCents, data.category, data.date);
      return toTransaction(row as unknown as TransactionRow);
    },
    findByPeriod(period) {
      const rows = findStmt.all(period.start, period.endExclusive);
      return (rows as unknown as TransactionRow[]).map(toTransaction);
    },
    sumByPeriod(period) {
      const row = sumStmt.get(period.start, period.endExclusive) as { income_cents: number; expense_cents: number };
      return { incomeCents: Number(row.income_cents), expenseCents: Number(row.expense_cents) };
    },
  };
}
