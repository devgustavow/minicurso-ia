export const TRANSACTION_TYPES = ['income', 'expense'] as const;
export type TransactionType = (typeof TRANSACTION_TYPES)[number];

export const CATEGORIES = [
  'Salário',
  'Freelance',
  'Investimentos',
  'Alimentação',
  'Moradia',
  'Transporte',
  'Saúde',
  'Educação',
  'Lazer',
  'Outros',
] as const;
export type Category = (typeof CATEGORIES)[number];

export const MAX_AMOUNT_CENTS = 9_999_999_999;
export const MAX_DESCRIPTION_LENGTH = 120;

export interface NewTransaction {
  type: TransactionType;
  description: string;
  amountCents: number;
  category: Category;
  date: string;
}

export interface Transaction extends NewTransaction {
  id: number;
  createdAt: string;
}

export interface MonthlySummary {
  incomeCents: number;
  expenseCents: number;
  balanceCents: number;
}

export interface MonthlyReport {
  month: string;
  transactions: Transaction[];
  summary: MonthlySummary;
}

export interface Period {
  start: string;
  endExclusive: string;
}

export interface PeriodTotals {
  incomeCents: number;
  expenseCents: number;
}
