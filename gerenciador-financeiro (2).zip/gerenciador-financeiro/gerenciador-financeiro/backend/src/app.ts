import express, { type Express, type Router } from 'express';
import { pinoHttp } from 'pino-http';
import { logger } from './logger.js';
import { errorHandler, notFoundHandler } from './routes/errors.js';
import { createHealthRouter } from './routes/healthRoutes.js';

export interface AppOptions {
  routers?: Router[];
}

export function createApp(options: AppOptions = {}): Express {
  const app = express();
  app.disable('x-powered-by');
  app.use(pinoHttp({ logger }));
  app.use(express.json({ limit: '10kb' }));
  app.use('/api', createHealthRouter());
  for (const router of options.routers ?? []) {
    app.use('/api', router);
  }
  app.use(notFoundHandler);
  app.use(errorHandler);
  return app;
}
