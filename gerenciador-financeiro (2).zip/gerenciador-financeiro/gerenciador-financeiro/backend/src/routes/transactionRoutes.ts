import { Router } from 'express';
import type { TransactionService } from '../services/transactionService.js';
import { HttpError, ValidationError } from './errors.js';

export function createTransactionRouter(service: TransactionService): Router {
  const router = Router();

  router.post('/transactions', (req, res) => {
    const result = service.createTransaction(req.body);
    if (!result.ok) {
      throw new ValidationError(result.errors);
    }
    res.status(201).json(result.value);
  });

  router.get('/transactions', (req, res) => {
    const result = service.getMonthly(req.query.month);
    if (!result.ok) {
      throw new HttpError(400, 'INVALID_MONTH', 'Informe o mês no formato AAAA-MM.', result.errors);
    }
    res.json(result.value);
  });

  return router;
}
