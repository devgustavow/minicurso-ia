import type { Server } from 'node:http';
import type { Logger } from './logger.js';

export interface ShutdownOptions {
  server: Server;
  closeResources: () => void;
  timeoutMs: number;
  logger: Logger;
  exit?: (code: number) => void;
  signalSource?: NodeJS.EventEmitter;
}

export function registerShutdown(options: ShutdownOptions): (signal: string) => void {
  const { server, closeResources, timeoutMs, logger } = options;
  const exit = options.exit ?? ((code: number) => process.exit(code));
  const signalSource = options.signalSource ?? process;
  let shuttingDown = false;

  const shutdown = (signal: string): void => {
    if (shuttingDown) {
      return;
    }
    shuttingDown = true;
    logger.info({ signal }, 'Encerrando o servidor');
    const forceTimer = setTimeout(() => {
      logger.error('Tempo limite de encerramento excedido; forçando saída');
      exit(1);
    }, timeoutMs);
    forceTimer.unref();
    server.close(() => {
      closeResources();
      clearTimeout(forceTimer);
      logger.info('Servidor encerrado');
      exit(0);
    });
    server.closeIdleConnections();
  };

  signalSource.on('SIGINT', () => shutdown('SIGINT'));
  signalSource.on('SIGTERM', () => shutdown('SIGTERM'));
  return shutdown;
}
