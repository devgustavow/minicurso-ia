import { spawn } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:net';
import { join } from 'node:path';
import { BACKEND_PORT, BACKEND_URL, FRONTEND_PORT, ROOT_DIR, STATE_FILE } from './environment.js';

export interface ServerState {
  backendPid: number;
  frontendPid: number;
  dbPath: string;
}

export function readState(): ServerState {
  return JSON.parse(readFileSync(STATE_FILE, 'utf8')) as ServerState;
}

export function writeState(state: ServerState): void {
  writeFileSync(STATE_FILE, JSON.stringify(state));
}

export function assertPortFree(port: number): Promise<void> {
  return new Promise((resolve, reject) => {
    const probe = createServer();
    probe.once('error', () => reject(new Error(`Porta ${port} ocupada; defina outra via variável de ambiente.`)));
    probe.listen(port, () => probe.close(() => resolve()));
  });
}

async function waitFor(url: string, timeoutMs = 20000): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const ready = await fetch(url).then((response) => response.ok, () => false);
    if (ready) return;
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  throw new Error(`Serviço não respondeu: ${url}`);
}

function startDetached(command: string, args: string[], cwd: string, env: Record<string, string>): number {
  const child = spawn(command, args, { cwd, env: { ...process.env, ...env }, stdio: 'ignore', detached: true });
  child.unref();
  if (!child.pid) throw new Error(`Falha ao iniciar ${command}`);
  return child.pid;
}

export async function startBackend(dbPath: string): Promise<number> {
  const pid = startDetached('node', ['--disable-warning=ExperimentalWarning', 'dist/server.js'], join(ROOT_DIR, 'backend'), {
    PORT: String(BACKEND_PORT),
    DB_PATH: dbPath,
    LOG_LEVEL: 'warn',
  });
  await waitFor(`${BACKEND_URL}/api/health`);
  return pid;
}

export async function startFrontend(): Promise<number> {
  const viteBin = join(ROOT_DIR, 'node_modules', 'vite', 'bin', 'vite.js');
  const pid = startDetached('node', [viteBin, 'preview'], join(ROOT_DIR, 'frontend'), {
    BACKEND_URL,
    FRONTEND_PORT: String(FRONTEND_PORT),
  });
  await waitFor(`http://localhost:${FRONTEND_PORT}/`);
  return pid;
}

function isAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

export async function stopProcess(pid: number, timeoutMs = 10000): Promise<void> {
  if (!isAlive(pid)) return;
  process.kill(pid, 'SIGTERM');
  const deadline = Date.now() + timeoutMs;
  while (isAlive(pid) && Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  if (isAlive(pid)) process.kill(pid, 'SIGKILL');
}

export async function restartBackend(): Promise<void> {
  const state = readState();
  await stopProcess(state.backendPid);
  await assertPortFree(BACKEND_PORT);
  writeState({ ...state, backendPid: await startBackend(state.dbPath) });
}
