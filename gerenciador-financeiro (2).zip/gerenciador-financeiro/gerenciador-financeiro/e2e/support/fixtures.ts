import { test as base, expect, type Page } from '@playwright/test';
import { join } from 'node:path';
import { EVIDENCE_DIR } from './environment.js';

export const TODAY = new Date('2026-10-15T12:00:00-03:00');

export interface EntryInput {
  type: 'Receita' | 'Despesa';
  description: string;
  amount: string;
  category: string;
  date: string;
}

export const test = base.extend<{ app: Page }>({
  app: async ({ page }, use) => {
    await page.clock.setFixedTime(TODAY);
    await page.goto('/');
    await expect(page.getByRole('heading', { level: 2, name: /de \d{4}$/ })).toBeVisible();
    await use(page);
  },
});

export { expect };

export async function fillEntry(page: Page, entry: EntryInput): Promise<void> {
  await page.getByRole('radio', { name: entry.type }).check();
  await page.getByLabel('Descrição').fill(entry.description);
  await page.getByLabel('Valor (R$)').fill(entry.amount);
  await page.getByLabel('Categoria').selectOption(entry.category);
  await page.getByLabel('Data').fill(entry.date);
}

export async function addEntry(page: Page, entry: EntryInput): Promise<void> {
  await fillEntry(page, entry);
  await page.getByRole('button', { name: 'Adicionar lançamento' }).click();
  await expect(page.getByRole('status')).toHaveText('Lançamento cadastrado com sucesso.');
}

export async function goToMonth(page: Page, month: string): Promise<void> {
  await page.getByLabel('Ir para o mês').fill(month);
}

export async function evidence(page: Page, name: string): Promise<void> {
  await page.screenshot({ path: join(EVIDENCE_DIR, `${name}.png`), fullPage: true });
}

export function entries(page: Page) {
  return page.getByRole('list', { name: 'Lançamentos' }).getByRole('listitem');
}
