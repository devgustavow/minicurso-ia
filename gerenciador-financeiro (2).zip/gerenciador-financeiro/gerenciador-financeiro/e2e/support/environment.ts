import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

export const ROOT_DIR = join(here, '..', '..');
export const TMP_DIR = join(here, '..', '.tmp');
export const STATE_FILE = join(TMP_DIR, 'state.json');
export const EVIDENCE_DIR = join(ROOT_DIR, 'tasks', 'prd-gerenciador-financeiro', 'evidences');

export const BACKEND_PORT = Number(process.env.E2E_BACKEND_PORT ?? 3031);
export const FRONTEND_PORT = Number(process.env.E2E_FRONTEND_PORT ?? 5131);
export const BACKEND_URL = `http://localhost:${BACKEND_PORT}`;
export const FRONTEND_URL = `http://localhost:${FRONTEND_PORT}`;
