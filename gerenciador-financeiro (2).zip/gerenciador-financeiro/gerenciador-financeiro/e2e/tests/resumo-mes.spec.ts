import { addEntry, entries, evidence, expect, goToMonth, test } from '../support/fixtures.js';

test('E2E-04: soma valores decimais sem erro e exibe saldo negativo', async ({ app: page }) => {
  await addEntry(page, { type: 'Receita', description: 'Troco A', amount: '0,10', category: 'Outros', date: '2027-03-02' });
  await addEntry(page, { type: 'Receita', description: 'Troco B', amount: '0,20', category: 'Outros', date: '2027-03-03' });
  await expect(page.getByTestId('receitas')).toHaveText('R$ 0,30');
  await expect(page.getByTestId('saldo')).toHaveText('R$ 0,30');
  await evidence(page, 'E2E-04-decimais-0-30');

  await addEntry(page, { type: 'Despesa', description: 'Mercado', amount: '50,30', category: 'Alimentação', date: '2027-03-04' });
  await expect(page.getByTestId('despesas')).toHaveText('R$ 50,30');
  await expect(page.getByTestId('saldo')).toHaveText('-R$ 50,00');
  await expect(page.getByText('Saldo negativo: as despesas superam as receitas.')).toBeVisible();
  await evidence(page, 'E2E-04-saldo-negativo');
});

test('E2E-05: abre no mês atual, troca de mês e mostra mês vazio zerado', async ({ app: page }) => {
  await expect(page.getByRole('heading', { name: 'Outubro de 2026' })).toBeVisible();
  await expect(page.getByLabel('Ir para o mês')).toHaveValue('2026-10');

  await page.getByRole('button', { name: 'Próximo mês' }).click();
  await expect(page.getByRole('heading', { name: 'Novembro de 2026' })).toBeVisible();
  await expect(page.getByText('Nenhum lançamento neste mês.')).toBeVisible();
  await expect(page.getByTestId('receitas')).toHaveText('R$ 0,00');
  await expect(page.getByTestId('despesas')).toHaveText('R$ 0,00');
  await expect(page.getByTestId('saldo')).toHaveText('R$ 0,00');
  await evidence(page, 'E2E-05-mes-vazio');

  await goToMonth(page, '2027-03');
  await expect(page.getByRole('heading', { name: 'Março de 2027' })).toBeVisible();
  await expect(entries(page)).toHaveCount(3);

  await page.getByRole('button', { name: 'Mês anterior' }).click();
  await expect(page.getByRole('heading', { name: 'Fevereiro de 2027' })).toBeVisible();
  await expect(page.getByText('Nenhum lançamento neste mês.')).toBeVisible();
});
