import { expect, test } from '@playwright/test';
import { writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { BACKEND_URL, EVIDENCE_DIR } from '../support/environment.js';

const valid = { type: 'expense', description: 'Direto na API', amountCents: 1000, category: 'Outros', date: '2027-07-10' };

const invalidCases: Array<[string, Record<string, unknown>, string]> = [
  ['valor zero', { ...valid, amountCents: 0 }, 'amountCents'],
  ['valor negativo', { ...valid, amountCents: -500 }, 'amountCents'],
  ['valor decimal', { ...valid, amountCents: 10.5 }, 'amountCents'],
  ['descrição vazia', { ...valid, description: '   ' }, 'description'],
  ['tipo ausente', { ...valid, type: undefined }, 'type'],
  ['categoria inválida', { ...valid, category: 'Viagem' }, 'category'],
  ['data inexistente', { ...valid, date: '2027-02-31' }, 'date'],
];

test('E2E-03: API rejeita lançamentos inválidos enviados diretamente', async ({ request }) => {
  const log: string[] = [];
  for (const [name, body, field] of invalidCases) {
    const response = await request.post(`${BACKEND_URL}/api/transactions`, { data: body });
    const json = (await response.json()) as { error: { code: string; details: Record<string, string> } };
    expect(response.status(), name).toBe(400);
    expect(json.error.code, name).toBe('VALIDATION_ERROR');
    expect(Object.keys(json.error.details), name).toContain(field);
    log.push(`${name}: ${response.status()} ${JSON.stringify(json.error.details)}`);
  }
  const emptyBody = await request.post(`${BACKEND_URL}/api/transactions`, { data: {} });
  expect(emptyBody.status()).toBe(400);
  log.push(`corpo vazio: ${emptyBody.status()} ${JSON.stringify((await emptyBody.json()).error.details)}`);

  const month = await request.get(`${BACKEND_URL}/api/transactions?month=2027-07`);
  expect((await month.json()).transactions).toEqual([]);
  log.push(`GET 2027-07 após tentativas: ${JSON.stringify(await month.json())}`);
  writeFileSync(join(EVIDENCE_DIR, 'E2E-03-api-validacao.txt'), `${log.join('\n')}\n`);
});
