import { restartBackend } from '../support/servers.js';
import { addEntry, entries, evidence, expect, goToMonth, test } from '../support/fixtures.js';

test('E2E-06: mantém os dados após recarregar a página e reiniciar o backend', async ({ app: page }) => {
  await addEntry(page, { type: 'Receita', description: 'Bônus anual', amount: '2.000,55', category: 'Salário', date: '2027-05-10' });
  await addEntry(page, { type: 'Despesa', description: 'Curso de inglês', amount: '450,25', category: 'Educação', date: '2027-05-12' });

  await page.reload();
  await goToMonth(page, '2027-05');
  await expect(entries(page)).toHaveCount(2);
  await expect(page.getByTestId('saldo')).toHaveText('R$ 1.550,30');
  await evidence(page, 'E2E-06-apos-recarregar');

  await restartBackend();
  await page.reload();
  await goToMonth(page, '2027-05');
  await expect(entries(page)).toHaveCount(2);
  await expect(entries(page).nth(0)).toContainText('Curso de inglês');
  await expect(entries(page).nth(1)).toContainText('Bônus anual');
  await expect(page.getByTestId('saldo')).toHaveText('R$ 1.550,30');
  await evidence(page, 'E2E-06-apos-reiniciar-backend');
});
