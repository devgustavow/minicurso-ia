import AxeBuilder from '@axe-core/playwright';
import { addEntry, entries, evidence, expect, fillEntry, goToMonth, test } from '../support/fixtures.js';

test('E2E-07: falha da API exibe alerta e preserva os dados digitados', async ({ app: page }) => {
  await page.route('**/api/transactions', (route) => (route.request().method() === 'POST' ? route.abort('failed') : route.continue()));
  await fillEntry(page, { type: 'Despesa', description: 'Farmácia', amount: '35,90', category: 'Saúde', date: '2026-10-11' });
  await page.getByRole('button', { name: 'Adicionar lançamento' }).click();
  await expect(page.getByRole('alert')).toHaveText('Não foi possível comunicar com o servidor. Tente novamente.');
  await expect(page.getByLabel('Descrição')).toHaveValue('Farmácia');
  await expect(page.getByLabel('Valor (R$)')).toHaveValue('35,90');
  await expect(page.getByLabel('Categoria')).toHaveValue('Saúde');
  await evidence(page, 'E2E-07-erro-comunicacao');
});

test('E2E-07: falha ao carregar o mês exibe alerta na listagem', async ({ page }) => {
  await page.route('**/api/transactions?*', (route) => route.fulfill({ status: 500, body: '{}' }));
  await page.goto('/');
  await expect(page.getByRole('alert')).toHaveText('Não foi possível comunicar com o servidor. Tente novamente.');
});

for (const [width, height, label] of [[320, 800, 'celular-320'], [768, 1000, 'tablet-768'], [1440, 900, 'desktop-1440']] as const) {
  test(`E2E-08: sem rolagem horizontal em ${width}px`, async ({ app: page }) => {
    await page.setViewportSize({ width, height });
    await goToMonth(page, '2026-10');
    for (const name of ['Novo lançamento', 'Lançamentos do mês']) {
      await expect(page.getByRole('heading', { name })).toBeVisible();
    }
    await expect(page.getByTestId('saldo')).toBeVisible();
    await expect(page.getByLabel('Ir para o mês')).toBeVisible();
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    expect(overflow).toBe(0);
    await evidence(page, `E2E-08-${label}`);
  });
}

test('E2E-09: cadastra e troca de mês usando apenas o teclado', async ({ app: page }) => {
  await page.getByRole('radio', { name: 'Receita' }).focus();
  await page.keyboard.press('ArrowRight');
  await expect(page.getByRole('radio', { name: 'Despesa' })).toBeChecked();
  await page.keyboard.press('Tab');
  await expect(page.getByLabel('Descrição')).toBeFocused();
  await page.keyboard.type('Cinema');
  await page.keyboard.press('Tab');
  await page.keyboard.type('42,50');
  await page.keyboard.press('Tab');
  await expect(page.getByLabel('Data')).toBeFocused();
  await page.getByLabel('Data').fill('2027-09-18');
  await expect(async () => {
    await page.keyboard.press('Tab');
    await expect(page.getByLabel('Categoria')).toBeFocused({ timeout: 100 });
  }).toPass({ timeout: 3000 });
  await page.keyboard.type('Lazer');
  await expect(page.getByLabel('Categoria')).toHaveValue('Lazer');
  await page.keyboard.press('Tab');
  await expect(page.getByRole('button', { name: 'Adicionar lançamento' })).toBeFocused();
  await page.keyboard.press('Enter');
  await expect(page.getByRole('status')).toHaveText('Lançamento cadastrado com sucesso.');
  await expect(page.getByRole('heading', { name: 'Setembro de 2027' })).toBeVisible();
  await expect(entries(page)).toHaveCount(1);

  await page.getByRole('button', { name: 'Mês anterior' }).focus();
  await page.keyboard.press('Enter');
  await expect(page.getByRole('heading', { name: 'Agosto de 2027' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Mês anterior' })).toBeFocused();
  await evidence(page, 'E2E-09-teclado');
});

test('E2E-10: sem violações sérias de acessibilidade (axe), incluindo contraste', async ({ app: page }) => {
  await addEntry(page, { type: 'Receita', description: 'Venda', amount: '99,90', category: 'Freelance', date: '2026-10-14' });
  await page.getByRole('button', { name: 'Adicionar lançamento' }).click();
  const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']).analyze();
  const serious = results.violations.filter((violation) => ['serious', 'critical'].includes(violation.impact ?? ''));
  expect(serious.map((violation) => `${violation.id}: ${violation.help}`)).toEqual([]);
});
