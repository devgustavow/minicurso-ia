import { addEntry, entries, evidence, expect, fillEntry, test } from '../support/fixtures.js';

test('E2E-01: cadastra receita e despesa com sucesso e atualiza listagem e resumo', async ({ app: page }) => {
  await addEntry(page, { type: 'Receita', description: 'Salário de outubro', amount: '3.500,00', category: 'Salário', date: '2026-10-05' });
  await expect(page.getByLabel('Descrição')).toHaveValue('');
  await expect(page.getByLabel('Valor (R$)')).toHaveValue('');
  await expect(page.getByRole('radio', { name: 'Receita' })).not.toBeChecked();

  await addEntry(page, { type: 'Despesa', description: 'Aluguel', amount: '1.200', category: 'Moradia', date: '2026-10-08' });
  await expect(page.getByRole('heading', { name: 'Outubro de 2026' })).toBeVisible();
  await expect(entries(page)).toHaveCount(2);
  await expect(entries(page).nth(0)).toContainText('Aluguel');
  await expect(entries(page).nth(0)).toContainText('Despesa');
  await expect(entries(page).nth(0)).toContainText('Moradia');
  await expect(entries(page).nth(0)).toContainText('08/10/2026');
  await expect(entries(page).nth(0)).toContainText('R$ 1.200,00');
  await expect(entries(page).nth(1)).toContainText('Receita');
  await expect(page.getByTestId('receitas')).toHaveText('R$ 3.500,00');
  await expect(page.getByTestId('despesas')).toHaveText('R$ 1.200,00');
  await expect(page.getByTestId('saldo')).toHaveText('R$ 2.300,00');
  await evidence(page, 'E2E-01-cadastro-receita-despesa');
});

test('E2E-01: lançamento de outro mês seleciona o mês da data', async ({ app: page }) => {
  await addEntry(page, { type: 'Despesa', description: 'Conta de luz de agosto', amount: '180,40', category: 'Moradia', date: '2026-08-20' });
  await expect(page.getByRole('heading', { name: 'Agosto de 2026' })).toBeVisible();
  await expect(entries(page)).toHaveCount(1);
  await expect(page.getByTestId('saldo')).toHaveText('-R$ 180,40');
});

test('E2E-02: bloqueia campos vazios, valor zero e negativo com mensagens por campo', async ({ app: page }) => {
  const submit = page.getByRole('button', { name: 'Adicionar lançamento' });
  await page.getByLabel('Data').fill('');
  await submit.click();
  await expect(page.getByRole('group', { name: 'Tipo' })).toContainText('Selecione o tipo.');
  await expect(page.getByLabel('Descrição')).toHaveAccessibleDescription('Informe a descrição.');
  await expect(page.getByLabel('Valor (R$)')).toHaveAccessibleDescription('Informe o valor.');
  await expect(page.getByLabel('Categoria')).toHaveAccessibleDescription('Selecione a categoria.');
  await expect(page.getByLabel('Data')).toHaveAccessibleDescription('Informe a data.');
  await expect(page.getByRole('radio', { name: 'Receita' })).toBeFocused();
  await evidence(page, 'E2E-02-campos-vazios');

  await fillEntry(page, { type: 'Despesa', description: 'Teste', amount: '0', category: 'Outros', date: '2026-10-01' });
  await submit.click();
  await expect(page.getByLabel('Valor (R$)')).toHaveAccessibleDescription('Informe um valor maior que zero.');
  await expect(page.getByLabel('Valor (R$)')).toBeFocused();

  await page.getByLabel('Valor (R$)').fill('-25,00');
  await submit.click();
  await expect(page.getByLabel('Valor (R$)')).toHaveAccessibleDescription('Informe um valor maior que zero.');

  await page.getByLabel('Valor (R$)').fill('1,999');
  await submit.click();
  await expect(page.getByLabel('Valor (R$)')).toHaveAccessibleDescription('Use no máximo 2 casas decimais.');
  await evidence(page, 'E2E-02-valor-invalido');
  await expect(page.getByRole('status')).toBeEmpty();
});
