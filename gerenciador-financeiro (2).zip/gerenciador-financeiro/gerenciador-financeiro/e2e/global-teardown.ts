import { existsSync, rmSync } from 'node:fs';
import { STATE_FILE, TMP_DIR } from './support/environment.js';
import { readState, stopProcess } from './support/servers.js';

export default async function globalTeardown(): Promise<void> {
  if (existsSync(STATE_FILE)) {
    const state = readState();
    await stopProcess(state.frontendPid);
    await stopProcess(state.backendPid);
  }
  rmSync(TMP_DIR, { recursive: true, force: true });
}
