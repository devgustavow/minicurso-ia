import { mkdirSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { BACKEND_PORT, EVIDENCE_DIR, FRONTEND_PORT, TMP_DIR } from './support/environment.js';
import { assertPortFree, startBackend, startFrontend, writeState } from './support/servers.js';

export default async function globalSetup(): Promise<void> {
  rmSync(TMP_DIR, { recursive: true, force: true });
  mkdirSync(TMP_DIR, { recursive: true });
  mkdirSync(EVIDENCE_DIR, { recursive: true });
  await assertPortFree(BACKEND_PORT);
  await assertPortFree(FRONTEND_PORT);
  const dbPath = join(TMP_DIR, 'e2e.db');
  const backendPid = await startBackend(dbPath);
  const frontendPid = await startFrontend();
  writeState({ backendPid, frontendPid, dbPath });
}
