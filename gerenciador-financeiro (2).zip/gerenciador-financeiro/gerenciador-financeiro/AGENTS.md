# AGENTS.md — Gerenciador Financeiro Pessoal

Guia para agentes e pessoas que trabalham neste repositório. Leia este arquivo e **todas** as rules em `.agents/rules/` antes de especificar, implementar, revisar ou validar qualquer mudança.

## Visão geral

Monorepo com npm workspaces:

| Pasta       | Conteúdo                                                        |
| ----------- | --------------------------------------------------------------- |
| `backend/`  | API REST em Node.js + TypeScript (Express), SQLite local         |
| `frontend/` | SPA em React + TypeScript + Tailwind CSS (Vite)                  |
| `e2e/`      | Testes ponta a ponta com Playwright (sobe backend e frontend)    |
| `tasks/`    | PRD, TechSpec, tarefas, revisão e QA de cada funcionalidade      |

## Requisitos

- Node.js 22 ou superior, npm 10 ou superior.
- Navegador do Playwright para os testes E2E: `npx playwright install chromium` (uma vez).

## Comandos (rodar na raiz)

| Objetivo                         | Comando                    |
| -------------------------------- | -------------------------- |
| Instalar dependências            | `npm install`              |
| Ambiente de desenvolvimento      | `npm run dev`              |
| Lint (backend + frontend + e2e)  | `npm run lint`             |
| Checagem de tipos                | `npm run typecheck`        |
| Testes de unidade e integração   | `npm test`                 |
| Testes com cobertura (mín. 80%)  | `npm run test:coverage`    |
| Build                            | `npm run build`            |
| Testes E2E                       | `npm run e2e`              |

Cada workspace também aceita os mesmos scripts (`npm run test -w backend`, por exemplo).

## Definição de pronto

Uma mudança só está pronta quando `npm run lint`, `npm run typecheck`, `npm run test:coverage` e, se afetar fluxos de interface, `npm run e2e` passam sem erros.

## Rules

| Arquivo                                 | Assunto                                         |
| --------------------------------------- | ----------------------------------------------- |
| `.agents/rules/code-standards.md`       | TypeScript, limites de tamanho, comentários     |
| `.agents/rules/backend.md`              | Estrutura, configuração, logger, shutdown, SQL  |
| `.agents/rules/frontend.md`             | Estrutura, React, Tailwind, acessibilidade      |
| `.agents/rules/money.md`                | Valores monetários em centavos inteiros         |
| `.agents/rules/testing.md`              | Vitest, Playwright, cobertura, nomenclatura      |

## Portas

Ao executar a aplicação em validações automatizadas, use o backend na faixa `3000–3099` e o frontend na faixa `5100–5199`, verificando antes se a porta está livre.
