# Tarefa 4 — Rotas da API

| Campo       | Valor |
| ----------- | ----- |
| Status      | Concluída |
| Depende de  | 3 |
| Critérios   | CA-01, CA-08–CA-10, CA-12–CA-14, CA-16, CA-17 |

## Entrega

`routes/transactionRoutes.ts` com `POST /api/transactions` e `GET /api/transactions?month=`, integradas ao `app.ts`.

Detalhes de implementação: [TechSpec](./techspec.md), seções 3 a 8.

## Subtarefas

- [x] 4.1 Implementar `POST /api/transactions` (201 / 400 `VALIDATION_ERROR`)
- [x] 4.2 Implementar `GET /api/transactions?month=` (200 / 400 `INVALID_MONTH`)
- [x] 4.3 Tratar JSON malformado (400 `INVALID_JSON`)
- [x] 4.4 Escrever os testes de integração com Supertest e banco temporário

## Testes (casos da TechSpec)

- [x] TI-01
- [x] TI-02
- [x] TI-03
- [x] TI-04
- [x] TI-05
- [x] TI-06
- [x] TI-08

## Validação

- [x] `npm run lint`
- [x] `npm run typecheck`
- [x] `npm run test:coverage` (≥ 80%)
