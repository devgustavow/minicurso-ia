# PRD — Gerenciador Financeiro Pessoal

| Campo        | Valor                         |
| ------------ | ----------------------------- |
| Slug         | `gerenciador-financeiro`      |
| Status       | Aprovado para especificação   |
| Data         | 15/10/2026                    |

## 1. Visão geral

Aplicação web simples para uma pessoa registrar suas receitas e despesas e acompanhar, mês a mês, quanto entrou, quanto saiu e qual é o saldo.

## 2. Problema

A pessoa usuária não tem uma forma simples de saber quanto entrou, quanto saiu e qual é o saldo de cada mês. Planilhas exigem fórmulas e disciplina; aplicativos bancários misturam contas e não refletem gastos em dinheiro ou de outras fontes.

## 3. Objetivos e métricas de sucesso

| Objetivo                                         | Métrica                                                                                   | Meta                      |
| ------------------------------------------------ | ----------------------------------------------------------------------------------------- | ------------------------- |
| Registrar um lançamento rapidamente              | Tempo para cadastrar um lançamento válido a partir da tela inicial                         | ≤ 30 segundos             |
| Mostrar o saldo do mês sem esforço               | Interações para ver totais e saldo de outro mês                                            | ≤ 2 interações            |
| Totais confiáveis                                | Diferença entre os totais exibidos e a soma exata dos lançamentos                          | R$ 0,00 (zero)            |
| Dados duradouros                                 | Lançamentos preservados após recarregar a página e reiniciar a aplicação                   | 100%                      |
| Dados íntegros                                   | Lançamentos inválidos aceitos pela API quando enviados sem passar pela interface           | 0                         |
| Acessível                                        | Fluxos principais completáveis apenas com teclado                                          | 100%                      |

## 4. Personas e histórias de usuário

**Persona:** pessoa adulta que controla as próprias finanças, usa celular e computador e quer algo mais simples que uma planilha.

- **HU-01** — Como pessoa usuária, quero registrar uma receita ou despesa com descrição, valor, categoria e data, para manter meu histórico financeiro.
- **HU-02** — Como pessoa usuária, quero ver os lançamentos de um mês, para conferir o que entrou e saiu.
- **HU-03** — Como pessoa usuária, quero ver o total de receitas, de despesas e o saldo do mês, para saber se fechei no positivo.
- **HU-04** — Como pessoa usuária, quero trocar o mês consultado, para comparar com meses anteriores.
- **HU-05** — Como pessoa usuária, quero que meus dados continuem lá quando eu voltar, para não perder meu histórico.

## 5. Fluxo principal

1. A pessoa abre a aplicação; o mês atual vem selecionado, com resumo e listagem desse mês.
2. Preenche o formulário (tipo, descrição, valor, categoria, data) e confirma.
3. A aplicação valida os campos; se houver erro, mostra a mensagem junto ao campo e não envia.
4. Com sucesso, mostra a confirmação, limpa o formulário, seleciona o mês da data do lançamento e atualiza resumo e listagem.
5. A pessoa troca o mês pelo seletor e vê a listagem e o resumo desse mês.

## 6. Requisitos funcionais

### RF-01 — Cadastrar lançamento

Campos, todos obrigatórios:

| Campo      | Regra                                                                                                        |
| ---------- | ------------------------------------------------------------------------------------------------------------ |
| Tipo       | `Receita` ou `Despesa`                                                                                       |
| Descrição  | Texto de 1 a 120 caracteres, desconsiderando espaços nas extremidades                                         |
| Valor      | Número positivo em reais, com até 2 casas decimais, entre R$ 0,01 e R$ 99.999.999,99                          |
| Categoria  | Uma da lista fixa: Salário, Freelance, Investimentos, Alimentação, Moradia, Transporte, Saúde, Educação, Lazer, Outros |
| Data       | Data de calendário válida (dia, mês e ano)                                                                    |

- **CA-01** — Com todos os campos válidos, ao confirmar, o lançamento é salvo, aparece a mensagem "Lançamento cadastrado com sucesso." e o formulário volta ao estado inicial.
- **CA-02** — Após o cadastro, o mês selecionado passa a ser o mês da data do lançamento, e o lançamento aparece na listagem com resumo atualizado, sem recarregar a página.
- **CA-03** — Com qualquer campo obrigatório vazio, o envio é bloqueado e cada campo vazio exibe sua própria mensagem de validação (ex.: "Informe a descrição.").
- **CA-04** — Valor igual a zero ou negativo é bloqueado com a mensagem "Informe um valor maior que zero.".
- **CA-05** — Valor com mais de 2 casas decimais, não numérico ou acima do máximo é bloqueado com mensagem específica no campo.
- **CA-06** — Descrição com mais de 120 caracteres ou só com espaços é bloqueada com mensagem no campo.
- **CA-07** — Data inexistente (ex.: 31/02/2026) ou categoria fora da lista é rejeitada.
- **CA-08** — A API rejeita, com status 400 e mensagem por campo, qualquer requisição de cadastro que viole CA-03 a CA-07, mesmo enviada diretamente (sem a interface), e nada é salvo.

### RF-02 — Listar lançamentos do mês

- **CA-09** — A listagem mostra apenas os lançamentos cuja data pertence ao mês selecionado, com tipo, descrição, valor em R$, categoria e data (dd/mm/aaaa).
- **CA-10** — A listagem é ordenada por data, da mais recente para a mais antiga; empates mantêm o mais recentemente cadastrado primeiro.
- **CA-11** — Receitas e despesas são distinguíveis por texto (não apenas por cor).

### RF-03 — Resumo do mês

- **CA-12** — O resumo exibe total de receitas, total de despesas e saldo (receitas − despesas) do mês selecionado.
- **CA-13** — Os totais são exatos para valores decimais: receitas de R$ 0,10 e R$ 0,20 resultam em total de receitas de exatamente R$ 0,30.
- **CA-14** — Saldo negativo é exibido com sinal de menos (ex.: "-R$ 50,00") e identificado textualmente como negativo.

### RF-04 — Trocar o mês consultado

- **CA-15** — Ao abrir a aplicação, o mês atual vem selecionado.
- **CA-16** — Ao escolher outro mês, listagem e resumo passam a refletir esse mês.
- **CA-17** — Em um mês sem lançamentos, a listagem mostra a mensagem "Nenhum lançamento neste mês." e receitas, despesas e saldo aparecem como R$ 0,00.

### RF-05 — Persistência

- **CA-18** — Após recarregar a página, todos os lançamentos cadastrados continuam visíveis no respectivo mês.
- **CA-19** — Após reiniciar a aplicação (backend), todos os lançamentos cadastrados continuam disponíveis com os mesmos dados.

### RF-06 — Mensagens e falhas

- **CA-20** — Se a API estiver indisponível ou responder com erro inesperado, a interface exibe "Não foi possível comunicar com o servidor. Tente novamente." sem perder os dados digitados no formulário.
- **CA-21** — Mensagens de sucesso e de erro são anunciadas a leitores de tela.

## 7. Requisitos não funcionais

### Interface e responsividade

- **CA-22** — Toda a interface está em português.
- **CA-23** — A interface é utilizável sem rolagem horizontal em larguras de 320 px (celular) a 1440 px (desktop), exibindo formulário, seletor de mês, resumo e listagem.

### Acessibilidade

- **CA-24** — Todos os fluxos (cadastrar, trocar mês, ler resumo e listagem) podem ser concluídos apenas com teclado, com foco visível.
- **CA-25** — Todo campo do formulário tem rótulo associado; mensagens de validação ficam vinculadas ao campo e são anunciadas.
- **CA-26** — Contraste de texto atende WCAG 2.1 AA.

### Desempenho

- **CA-27** — Com até 1.000 lançamentos no mês, a troca de mês atualiza a tela em até 1 segundo em ambiente local.

## 8. Fora do escopo

Autenticação, múltiplos usuários, gráficos, importação bancária, integrações externas, edição em massa. Edição e exclusão individual de lançamentos, categorias personalizadas, múltiplas moedas e exportação também ficam fora desta versão.

## 9. Premissas e decisões

| #   | Premissa                                                                                                         |
| --- | ---------------------------------------------------------------------------------------------------------------- |
| P-1 | Uso por uma única pessoa em ambiente local; não há dados sensíveis de terceiros.                                  |
| P-2 | Categorias são uma lista fixa única, válida para receitas e despesas.                                              |
| P-3 | Datas passadas e futuras são aceitas (permite registrar contas a pagar).                                           |
| P-4 | O "mês atual" é determinado pelo relógio do dispositivo da pessoa usuária.                                         |
| P-5 | Valor máximo de R$ 99.999.999,99 por lançamento, suficiente para uso pessoal.                                      |

## 10. Dependências e riscos

| Risco                                                  | Mitigação                                                          |
| ------------------------------------------------------ | ------------------------------------------------------------------ |
| Erros de arredondamento em somas de valores decimais   | Requisito de totais exatos (CA-13), verificado por testes          |
| Dados inválidos inseridos por fora da interface        | Validação obrigatória também na API (CA-08)                        |
| Perda de dados ao reiniciar                            | Persistência durável verificada por teste de reinício (CA-19)      |
