# Revisão de código — Gerenciador Financeiro Pessoal

| Campo        | Valor                                   |
| ------------ | --------------------------------------- |
| Funcionalidade | `gerenciador-financeiro`              |
| Data         | 15/10/2026                              |
| Escopo       | Tarefas 1 a 7 (`tasks.md`)              |
| Veredito     | **APROVADO COM RESSALVAS**              |

## 1. Resumo

A implementação segue a arquitetura da TechSpec (Express em camadas + SQLite; React + Tailwind com proxy do Vite), com valores sempre em centavos inteiros, queries parametrizadas e validação duplicada na interface e na API. Todos os testes passam e a cobertura supera 80% nos dois workspaces. Uma violação de rule foi encontrada e corrigida durante a revisão (URL da API). As ressalvas são melhorias não bloqueantes listadas na seção 7.

## 2. Conformidade com as rules

| Rule                         | Verificação                                                                                          | Resultado |
| ---------------------------- | ---------------------------------------------------------------------------------------------------- | --------- |
| `code-standards.md`          | `strict` em todos os workspaces; nenhum `any` (lint `no-explicit-any` + busca); maior arquivo 114 linhas; funções ≤ 40 e componentes ≤ 120 linhas garantidos por ESLint (`max-lines`, `max-lines-per-function`) | Conforme  |
| `code-standards.md`          | Comentários: nenhum comentário no código-fonte                                                        | Conforme  |
| `backend.md`                 | Pastas `routes/`, `services/`, `data/`, `types/`; `dotenv` só em `config.ts`; `.env.example`; logger `pino` único, sem `console.*` (lint `no-console`); graceful shutdown com timeout; erros no formato padronizado | Conforme  |
| `backend.md`                 | SQL: três `prepare` com `?`; a única interpolação é a constante `SELECT_COLUMNS`, sem dado externo  | Conforme  |
| `frontend.md`                | Pastas `components/`, `views/`, `services/`, `hooks/`, `types/` (+ `utils/`); só `services/` faz HTTP; estilo só com Tailwind; a11y com `label`, `aria-describedby`, `aria-invalid`, `role="status"`/`alert` | Conforme  |
| `frontend.md`                | URL da API via `VITE_API_URL`                                                                         | **Corrigido** (V-01) |
| `money.md`                   | `INTEGER` no banco, inteiros no TS, `SUM` de inteiros; conversão por string em `parseAmountToCents`; divisão por 100 só em `formatCents` | Conforme  |
| `testing.md`                 | Vitest + Supertest + Testing Library; Playwright em `e2e/`; casos nomeados com IDs da TechSpec; limiar de 80% configurado | Conforme  |

## 3. Aderência à TechSpec

- [x] Arquitetura conforme especificado (camadas, proxy do Vite, sem CORS)
- [x] Componentes, interfaces e contratos conforme definidos
- [x] Modelo de dados conforme documentado (tabela, `CHECK`s, índice por data, WAL)
- [x] Endpoints `POST /api/transactions`, `GET /api/transactions?month=`, `GET /api/health`, 404 e 500 conforme especificados

Desvios justificados:

| #    | Desvio                                                                                     | Justificativa                                                                 |
| ---- | ------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------- |
| DJ-1 | `backend/src/types/result.ts` (tipo `Result`) não listado na TechSpec                       | Tipo compartilhado entre validação e service; sem impacto em contratos        |
| DJ-2 | `components/TypeField.tsx` extraído de `TransactionForm`                                    | Mantém o componente abaixo de 120 linhas (rule de tamanho)                    |
| DJ-3 | `CATEGORIES` duplicado entre backend e frontend                                             | Já registrado na TechSpec (seção 10); coberto pelos E2E                        |

## 4. Completude das tarefas

| Tarefa | Código | CA rastreados | Subtarefas | Testes da tarefa |
| ------ | ------ | ------------- | ---------- | ---------------- |
| 1 — Estrutura | Sim | Sim | 6/6 | TI-08 (404/500/JSON), TI-09 |
| 2 — Persistência | Sim | Sim | 4/4 | TI-07, TI-10 |
| 3 — Services | Sim | Sim | 4/4 | TU-01 a TU-09 |
| 4 — Rotas | Sim | Sim | 4/4 | TI-01 a TI-06, TI-08 |
| 5 — Serviços/hooks frontend | Sim | Sim | 6/6 | TU-10 a TU-14, TU-20 |
| 6 — Componentes e tela | Sim | Sim | 4/4 | TU-15 a TU-19, TU-21 |
| 7 — E2E | Sim | Sim | 4/4 | E2E-01 a E2E-10 |

## 5. Testes e validações executados

| Comando                 | Resultado                                                                 |
| ----------------------- | ------------------------------------------------------------------------- |
| `npm run lint`          | 0 erros, 0 avisos                                                          |
| `npm run typecheck`     | 0 erros (backend, frontend, e2e)                                           |
| `npm run test:coverage` | Backend: 63 testes, cobertura 100% linhas / 98,37% branches / 96,96% funções. Frontend: 67 testes, 100% linhas / 99,47% branches / 100% funções |
| `npm run build`         | OK                                                                        |
| `npm run e2e`           | 14 testes passando (backend na porta 3031, frontend na 5131, banco temporário) |

## 6. Problemas encontrados e corrigidos

| #    | Severidade | Problema                                                                                 | Correção                                                                                   |
| ---- | ---------- | ---------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| V-01 | Média      | `frontend.md` exige a URL da API via `VITE_API_URL`; o serviço usava caminho fixo `/api` | `transactionsApi.ts` prefixa as rotas com `VITE_API_URL` (padrão vazio = mesma origem); tipagem em `vite-env.d.ts`; `frontend/.env.example` |
| V-02 | Baixa      | `@axe-core/playwright` trazia `playwright-core` 1.64, incompatível com os tipos do `@playwright/test` 1.56 | `overrides` no `package.json` raiz alinhando `playwright-core` em 1.56.0              |

## 7. Recomendações (não bloqueantes)

1. Se `VITE_API_URL` apontar para outra origem, o backend precisará de CORS; hoje o uso suportado é mesma origem/proxy.
2. `node:sqlite` emite aviso experimental no Node 22; os scripts já o silenciam. Reavaliar ao migrar para Node 24, onde o módulo é estável.
3. Os E2E de `resumo-mes.spec.ts` compartilham dados entre E2E-04 e E2E-05 (março/2027). Funciona com `workers: 1`, mas isolar os dados facilitaria paralelizar.
4. No E2E-09 a data é preenchida com `fill`, pois a ordem dos segmentos do campo de data nativo varia com o idioma do navegador; o restante do fluxo é feito só com teclado.
