# Tarefa 6 — Componentes e tela

| Campo       | Valor |
| ----------- | ----- |
| Status      | Concluída |
| Depende de  | 5 |
| Critérios   | CA-01–CA-04, CA-09, CA-11, CA-12, CA-14–CA-17, CA-20–CA-26 |

## Entrega

`components/` (FormField, TransactionForm, MonthSelector, SummaryCards, TransactionList, StatusMessage) e `views/FinanceView.tsx`, responsivos e acessíveis.

Detalhes de implementação: [TechSpec](./techspec.md), seções 3 a 8.

## Subtarefas

- [x] 6.1 Implementar `FormField` e `TransactionForm` com erros por campo acessíveis
- [x] 6.2 Implementar `MonthSelector`, `SummaryCards`, `TransactionList` e `StatusMessage`
- [x] 6.3 Compor `FinanceView` com layout responsivo (mobile-first) e região de status anunciada
- [x] 6.4 Escrever os testes de componentes e da view

## Testes (casos da TechSpec)

- [x] TU-15
- [x] TU-16
- [x] TU-17
- [x] TU-18
- [x] TU-19
- [x] TU-21

## Validação

- [x] `npm run lint`
- [x] `npm run typecheck`
- [x] `npm run test:coverage` (≥ 80%)
