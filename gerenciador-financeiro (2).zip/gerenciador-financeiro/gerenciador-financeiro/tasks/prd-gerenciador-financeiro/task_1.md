# Tarefa 1 — Estrutura e configuração do projeto

| Campo       | Valor |
| ----------- | ----- |
| Status      | Concluída |
| Depende de  | — |
| Critérios   | CA-22 (base) |

## Entrega

Monorepo com workspaces `backend` e `frontend`, pasta `e2e/`, TypeScript strict, ESLint, Vitest com limite de cobertura de 80%, Tailwind, `config.ts`, `logger.ts`, `app.ts` com `GET /api/health`, `server.ts` e `shutdown.ts`.

Detalhes de implementação: [TechSpec](./techspec.md), seções 3 a 8.

## Subtarefas

- [x] 1.1 Criar `package.json` raiz com workspaces e scripts do AGENTS.md (`lint`, `typecheck`, `test`, `test:coverage`, `build`, `dev`, `e2e`)
- [x] 1.2 Configurar backend: TypeScript, ESLint, Vitest (cobertura ≥ 80%), `dotenv` em `config.ts`, `.env.example`, `logger.ts` (pino)
- [x] 1.3 Criar `app.ts` com JSON parser, `pino-http`, `GET /api/health`, 404 e middleware de erro padronizado (`routes/errors.ts`)
- [x] 1.4 Criar `server.ts` e `shutdown.ts` com graceful shutdown (`SIGINT`/`SIGTERM`, timeout)
- [x] 1.5 Configurar frontend: Vite + React + TypeScript + Tailwind, proxy `/api` → `BACKEND_URL`, ESLint, Vitest + Testing Library (jsdom)
- [x] 1.6 Escrever testes de saúde, 404/500 e shutdown

## Testes (casos da TechSpec)

- [x] TI-08 (parte 404/500)
- [x] TI-09

## Validação

- [x] `npm run lint`
- [x] `npm run typecheck`
- [x] `npm run test:coverage` (≥ 80%)
