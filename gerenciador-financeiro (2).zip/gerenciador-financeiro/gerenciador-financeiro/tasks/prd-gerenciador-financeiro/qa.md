# QA — Gerenciador Financeiro Pessoal

| Campo        | Valor                                                                 |
| ------------ | --------------------------------------------------------------------- |
| Funcionalidade | `gerenciador-financeiro`                                            |
| Data         | 15/10/2026                                                            |
| Ferramenta de navegador | Playwright 1.56 (Chromium headless)                        |
| Ambiente E2E | Backend `http://localhost:3031`, frontend `http://localhost:5131` (vite preview), SQLite temporário |
| Ambiente exploratório | Backend `http://localhost:3032`, frontend `http://localhost:5132`, SQLite temporário |
| Status       | **APROVADO**                                                          |

## 1. Resumo

Os 27 critérios de aceitação do PRD foram verificados e estão atendidos. Foi encontrado e corrigido um defeito (QA-01: valor "1.000" rejeitado), com teste de regressão de unidade e cobertura no E2E-01. Na rodada final: 63 testes no backend, 70 no frontend, 14 E2E, lint e checagem de tipos sem erros, cobertura ≥ 96% em todas as métricas.

## 2. Checklist de critérios de aceitação

| CA    | Verificação                                                           | Casos                         | Evidência                                        | Resultado |
| ----- | --------------------------------------------------------------------- | ----------------------------- | ------------------------------------------------ | --------- |
| CA-01 | Cadastro válido salva, mostra sucesso e limpa o formulário             | TU-01, TU-16, TI-01, E2E-01   | `E2E-01-cadastro-receita-despesa.png`            | PASSOU    |
| CA-02 | Mês selecionado passa a ser o do lançamento; lista e resumo atualizam  | TU-21, E2E-01                 | `E2E-01-cadastro-receita-despesa.png`            | PASSOU    |
| CA-03 | Campos vazios bloqueados com mensagem por campo                        | TU-02, TU-13, TU-15, E2E-02   | `E2E-02-campos-vazios.png`, `QA-celular-validacao.png` | PASSOU |
| CA-04 | Valor zero ou negativo bloqueado                                       | TU-03, TU-11, E2E-02          | `E2E-02-valor-invalido.png`                      | PASSOU    |
| CA-05 | Mais de 2 casas, não numérico ou acima do máximo bloqueado             | TU-04, TU-11, E2E-02          | `E2E-02-valor-invalido.png`                      | PASSOU    |
| CA-06 | Descrição > 120 caracteres ou só espaços bloqueada                     | TU-05, TU-13, exploratório    | Saída do roteiro exploratório (seção 5)          | PASSOU    |
| CA-07 | Data inexistente ou categoria fora da lista rejeitada                  | TU-06, TU-07, TU-13, E2E-03   | `E2E-03-api-validacao.txt`                       | PASSOU    |
| CA-08 | API rejeita inválidos com 400 por campo, sem gravar                    | TU-02–TU-07, TI-02, E2E-03    | `E2E-03-api-validacao.txt`                       | PASSOU    |
| CA-09 | Lista só o mês selecionado, com todos os dados                         | TU-18, TI-03, E2E-01, E2E-05  | `E2E-01-cadastro-receita-despesa.png`            | PASSOU    |
| CA-10 | Ordenação por data decrescente, desempate pelo mais recente            | TI-03, E2E-06                 | `E2E-06-apos-reiniciar-backend.png`              | PASSOU    |
| CA-11 | Receita/Despesa identificadas por texto                                | TU-18, E2E-01                 | `E2E-01-cadastro-receita-despesa.png`            | PASSOU    |
| CA-12 | Resumo com receitas, despesas e saldo                                  | TU-09, TU-17, TI-04, E2E-01   | `E2E-01-cadastro-receita-despesa.png`            | PASSOU    |
| CA-13 | 0,10 + 0,20 = R$ 0,30 exato                                            | TU-10, TU-12, TI-04, E2E-04   | `E2E-04-decimais-0-30.png`                       | PASSOU    |
| CA-14 | Saldo negativo com sinal e texto                                       | TU-09, TU-17, TI-04, E2E-04   | `E2E-04-saldo-negativo.png`                      | PASSOU    |
| CA-15 | Mês atual selecionado ao abrir                                         | TU-14, E2E-05                 | `E2E-05-mes-vazio.png` (navegação a partir de outubro/2026) | PASSOU |
| CA-16 | Troca de mês atualiza lista e resumo                                   | TU-08, TU-19, TI-06, E2E-05   | `E2E-05-mes-vazio.png`                           | PASSOU    |
| CA-17 | Mês vazio: mensagem e totais R$ 0,00                                   | TU-18, TI-05, E2E-05          | `E2E-05-mes-vazio.png`, `QA-celular-vazio.png`   | PASSOU    |
| CA-18 | Dados mantidos após recarregar a página                                | E2E-06                        | `E2E-06-apos-recarregar.png`                     | PASSOU    |
| CA-19 | Dados mantidos após reiniciar o backend                                | TI-07, TI-09, E2E-06          | `E2E-06-apos-reiniciar-backend.png`              | PASSOU    |
| CA-20 | Falha da API mostra mensagem e preserva os campos                      | TU-20, TU-21, TI-08, E2E-07   | `E2E-07-erro-comunicacao.png`                    | PASSOU    |
| CA-21 | Sucesso (`role="status"`) e erro (`role="alert"`) anunciados           | TU-21, E2E-01, E2E-07         | `E2E-07-erro-comunicacao.png`                    | PASSOU    |
| CA-22 | Interface toda em português                                            | E2E-08, inspeção visual       | `E2E-08-*.png`                                   | PASSOU    |
| CA-23 | Sem rolagem horizontal de 320 px a 1440 px                             | E2E-08                        | `E2E-08-celular-320.png`, `E2E-08-tablet-768.png`, `E2E-08-desktop-1440.png` | PASSOU |
| CA-24 | Fluxos completos só com teclado, foco visível                          | E2E-09, exploratório          | `E2E-09-teclado.png`, `QA-foco-visivel.png`      | PASSOU    |
| CA-25 | Rótulos associados; erros vinculados e anunciados                      | TU-15, E2E-02, E2E-10         | `E2E-02-campos-vazios.png`                       | PASSOU    |
| CA-26 | Contraste WCAG 2.1 AA                                                  | E2E-10 (axe, tags wcag2aa/wcag21aa) | Execução sem violações sérias               | PASSOU    |
| CA-27 | Mês com 1.000 lançamentos em < 1 s                                     | TI-10                         | Saída do Vitest                                  | PASSOU    |

## 3. Casos de teste da TechSpec

| Camada | Casos | Comando | Resultado |
| ------ | ----- | ------- | --------- |
| Unidade backend | TU-01 a TU-09 | `npm run test:coverage -w backend` | Passaram |
| Unidade frontend | TU-10 a TU-21 + regressão QA-01 | `npm run test:coverage -w frontend` | Passaram |
| Integração | TI-01 a TI-10 | `npm run test:coverage -w backend` | Passaram |
| E2E | E2E-01 a E2E-10 (14 testes) | `npm run e2e` | Passaram |

Cobertura (meta 80%):

| Workspace | Linhas | Branches | Funções | Statements |
| --------- | ------ | -------- | ------- | ---------- |
| backend   | 100%   | 98,37%   | 96,96%  | 100%       |
| frontend  | 100%   | 99,47%   | 100%    | 100%       |

## 4. Acessibilidade

| Item | Resultado |
| ---- | --------- |
| Navegação por teclado (Tab, Enter, setas) | OK — E2E-09; foco vai ao primeiro campo inválido após envio com erro. Não há diálogos, então Esc não se aplica |
| Elementos interativos com rótulos descritivos | OK — setas do seletor com `aria-label` "Mês anterior"/"Próximo mês" |
| Imagens com `alt` | Não há imagens (verificado: 0 `img` sem `alt`) |
| Contraste de cores | OK — axe sem violações sérias |
| Formulários com rótulos associados | OK — `label for`, `fieldset/legend` no tipo |
| Mensagens de erro claras e acessíveis | OK — `aria-invalid`, `aria-describedby`, `role="alert"` |
| Fontes com tamanho apropriado | OK — corpo 16 px; menor texto 12 px apenas nas etiquetas Receita/Despesa (negrito) |

## 5. Verificação exploratória (celular, 375 px)

Roteiro executado com Playwright no ambiente exploratório:

| Verificação | Resultado observado |
| ----------- | ------------------- |
| Foco após envio vazio | Vai para "Receita" (primeiro campo com erro) |
| Contorno de foco | `solid 3px` na cor de destaque |
| Descrição com 130 caracteres | "A descrição deve ter no máximo 120 caracteres." |
| Duplo clique em "Adicionar lançamento" | Apenas 1 lançamento criado (botão desabilitado durante o envio) |
| Valor "1.000" | Aceito e exibido como R$ 1.000,00 (após correção do QA-01) |
| Erros no console do navegador | Nenhum |

Evidências: `QA-celular-vazio.png`, `QA-celular-validacao.png`, `QA-foco-visivel.png`, `QA-celular-com-dados.png`.

## 6. Visual e responsividade

Estados capturados: vazio (`E2E-05-mes-vazio.png`, `QA-celular-vazio.png`), com dados (`E2E-01-*.png`, `QA-celular-com-dados.png`) e erro (`E2E-07-erro-comunicacao.png`, `QA-celular-validacao.png`), em 320, 375, 768 e 1440 px.

Inconsistências documentadas (não bloqueantes):

- O campo de data nativo segue o idioma do navegador; no Chromium de teste em inglês aparece como mm/dd/aaaa, mas em navegadores em português aparece como dd/mm/aaaa. A listagem sempre mostra dd/mm/aaaa.

## 7. Defeitos

| ID    | Severidade | Descrição | Causa raiz | Correção | Teste de regressão | Status |
| ----- | ---------- | --------- | ---------- | -------- | ------------------ | ------ |
| QA-01 | Média | Digitar "1.000" (mil reais, notação brasileira) era rejeitado com "Use no máximo 2 casas decimais." | `parseAmountToCents` tratava um único ponto sempre como separador decimal | Ponto seguido de grupos de exatamente 3 dígitos passa a ser separador de milhar (`utils/money.ts`); regra atualizada na TechSpec, seção 6 | `money.test.ts` "regressão QA-01" (falha sem a correção: 4 testes; passa com ela) e E2E-01 usando "1.200" | Corrigido |

## 8. Encerramento do ambiente

Todos os processos iniciados (backend e `vite preview` nas portas 3031/5131 e 3032/5132) foram encerrados com SIGTERM; o backend registrou encerramento gracioso e as portas foram confirmadas livres. Os bancos temporários foram removidos.
