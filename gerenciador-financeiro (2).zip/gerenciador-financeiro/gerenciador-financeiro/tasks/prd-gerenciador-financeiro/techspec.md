# TechSpec — Gerenciador Financeiro Pessoal

| Campo | Valor                                                    |
| ----- | -------------------------------------------------------- |
| PRD   | [`prd.md`](./prd.md)                                     |
| Slug  | `gerenciador-financeiro`                                 |
| Data  | 15/10/2026                                               |

## 1. Resumo da solução

SPA em React + Tailwind que conversa com uma API REST em Node.js/Express. A API valida as entradas, grava em SQLite local (arquivo em disco) e calcula, para um mês `YYYY-MM`, a lista de lançamentos e o resumo (receitas, despesas, saldo). Todos os valores trafegam e são calculados em **centavos inteiros**; a conversão para R$ ocorre só no formulário e na exibição. Problema, objetivos e escopo estão no PRD.

## 2. Arquitetura

```
Navegador ──HTTP──► Vite (dev/preview) ──proxy /api──► Express (backend)
  React SPA                                           routes → services → data → SQLite (arquivo)
```

- O frontend chama sempre caminhos relativos `/api/...`. Em desenvolvimento e no `vite preview` (usado no E2E), o Vite faz proxy para o backend (`BACKEND_URL`), dispensando CORS.
- Backend em camadas, conforme `.agents/rules/backend.md`: `routes/` (HTTP) → `services/` (regras e validação) → `data/` (SQL).
- Frontend conforme `.agents/rules/frontend.md`: `views/` compõe `components/` e `hooks/`; só `services/` faz HTTP.

### Decisões

| #    | Decisão                                                                                     | Alternativa descartada e motivo                                                    |
| ---- | ------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| D-01 | SQLite via módulo nativo do Node 22 (`node:sqlite`, `DatabaseSync`)                          | `better-sqlite3`: exige binário nativo compilado; `node:sqlite` já vem no runtime   |
| D-02 | Centavos como `INTEGER` no banco e `number` inteiro no TS; somas via `SUM()` de inteiros     | `REAL`/float: erros de arredondamento (CA-13)                                       |
| D-03 | Validação com funções puras próprias no backend e no frontend                                | Biblioteca de schema: regras são poucas e as mensagens são específicas do PRD       |
| D-04 | Filtro de mês por intervalo de strings ISO (`date >= ? AND date < ?`)                        | `strftime` na coluna: impede uso do índice                                          |
| D-05 | Logger `pino` (+ `pino-http` para requisições)                                               | `winston`: mais configuração para o mesmo resultado                                 |
| D-06 | Proxy do Vite em vez de CORS                                                                 | Pacote `cors`: dependência e configuração extra sem ganho para uso local            |

## 3. Componentes

### Backend (`backend/src/`)

| Arquivo                                   | Responsabilidade                                                                                  |
| ----------------------------------------- | ------------------------------------------------------------------------------------------------- |
| `config.ts`                               | Carrega `.env` com `dotenv`; exporta `PORT`, `DB_PATH`, `LOG_LEVEL`, `SHUTDOWN_TIMEOUT_MS` tipados |
| `logger.ts`                               | Instância única do `pino`                                                                         |
| `app.ts`                                  | `createApp(deps)`: JSON parser, `pino-http`, rotas, 404 e handler de erros                         |
| `server.ts`                               | Abre o banco, sobe o HTTP e registra o graceful shutdown (`SIGINT`/`SIGTERM`)                     |
| `shutdown.ts`                             | `registerShutdown(server, db, timeoutMs)`: fecha servidor e banco; força saída após o timeout      |
| `data/database.ts`                        | `openDatabase(path)`: cria diretório, abre `DatabaseSync`, aplica migração idempotente             |
| `data/transactionRepository.ts`           | `insert`, `findByPeriod`, `sumByPeriod` — queries parametrizadas                                  |
| `services/transactionValidation.ts`       | `validateNewTransaction(input: unknown)` → `Result<NewTransaction, FieldErrors>`                  |
| `services/month.ts`                       | `parseMonth(value)` → `{ start, endExclusive }` ou erro                                            |
| `services/transactionService.ts`          | `createTransaction`, `getMonthly(month)` (lista + resumo)                                          |
| `routes/transactionRoutes.ts`             | `POST /api/transactions`, `GET /api/transactions?month=`                                           |
| `routes/healthRoutes.ts`                  | `GET /api/health`                                                                                  |
| `routes/errors.ts`                        | `HttpError`, `ValidationError`, middleware de erro no formato padronizado                         |
| `types/transaction.ts`                    | `TransactionType`, `Category`, `Transaction`, `NewTransaction`, `MonthlySummary`, `CATEGORIES`     |

### Frontend (`frontend/src/`)

| Arquivo                                   | Responsabilidade                                                                         |
| ----------------------------------------- | ---------------------------------------------------------------------------------------- |
| `main.tsx`, `App.tsx`                     | Bootstrap e montagem da view                                                             |
| `views/FinanceView.tsx`                   | Layout: formulário, seletor de mês, resumo e listagem; região `aria-live` de status       |
| `components/TransactionForm.tsx`          | Formulário controlado; exibe erros por campo; desabilita o botão durante o envio          |
| `components/FormField.tsx`                | Rótulo + controle + mensagem de erro com `aria-describedby`/`aria-invalid`                |
| `components/MonthSelector.tsx`            | Botões "Mês anterior"/"Próximo mês" e `<input type="month">`                             |
| `components/SummaryCards.tsx`             | Receitas, despesas e saldo (com indicação textual de saldo negativo)                     |
| `components/TransactionList.tsx`          | Lista do mês ou estado vazio                                                             |
| `components/StatusMessage.tsx`            | Mensagem de sucesso (`role="status"`) ou erro (`role="alert"`)                            |
| `hooks/useMonthlyTransactions.ts`         | Busca lista e resumo do mês; estados `loading`/`error`; `reload()`                        |
| `hooks/useTransactionForm.ts`             | Estado do formulário, validação, envio, mapeamento de erros da API para campos            |
| `services/transactionsApi.ts`             | `createTransaction`, `fetchMonthly`; lança `ApiValidationError` ou `ApiConnectionError`  |
| `utils/money.ts`                          | `parseAmountToCents(text)`, `formatCents(cents)`                                          |
| `utils/date.ts`                           | `currentMonth(now)`, `shiftMonth`, `monthOf(date)`, `formatDate`, `formatMonthLabel`      |
| `utils/validation.ts`                     | `validateForm(values)` com as mensagens do PRD                                            |
| `types/transaction.ts`                    | Tipos e `CATEGORIES` (espelho do backend)                                                 |

## 4. Modelo de dados

```sql
CREATE TABLE IF NOT EXISTS transactions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  type         TEXT    NOT NULL CHECK (type IN ('income', 'expense')),
  description  TEXT    NOT NULL CHECK (length(description) BETWEEN 1 AND 120),
  amount_cents INTEGER NOT NULL CHECK (amount_cents > 0 AND amount_cents <= 9999999999),
  category     TEXT    NOT NULL,
  date         TEXT    NOT NULL,          -- 'YYYY-MM-DD'
  created_at   TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions (date);
```

As restrições `CHECK` são uma segunda barreira; a validação do service é a fonte das mensagens. `PRAGMA journal_mode = WAL` para escrita durável.

## 5. Contratos da API

Base: `/api`. Corpos em JSON. Erros sempre em `{ "error": { "code", "message", "details"? } }`.

### `POST /api/transactions`

Requisição:

```json
{ "type": "income", "description": "Salário", "amountCents": 350000, "category": "Salário", "date": "2026-10-05" }
```

| Campo         | Regra                                                                                      |
| ------------- | ------------------------------------------------------------------------------------------ |
| `type`        | `"income"` ou `"expense"`                                                                  |
| `description` | string; após `trim`, 1–120 caracteres (gravada sem espaços nas extremidades)                |
| `amountCents` | inteiro (`Number.isSafeInteger`), 1 a 9.999.999.999                                         |
| `category`    | uma de `CATEGORIES` (PRD RF-01)                                                             |
| `date`        | string `YYYY-MM-DD` que represente data de calendário existente                            |

Respostas:

- `201` — o lançamento criado: `{ "id": 1, "type": "income", "description": "Salário", "amountCents": 350000, "category": "Salário", "date": "2026-10-05", "createdAt": "..." }`
- `400` — `{ "error": { "code": "VALIDATION_ERROR", "message": "Dados inválidos.", "details": { "amountCents": "Informe um valor maior que zero." } } }`
- `400` — JSON malformado: `code: "INVALID_JSON"`

### `GET /api/transactions?month=YYYY-MM`

- `200`:

```json
{
  "month": "2026-10",
  "transactions": [ { "id": 2, "type": "expense", "description": "Mercado", "amountCents": 2050, "category": "Alimentação", "date": "2026-10-10", "createdAt": "..." } ],
  "summary": { "incomeCents": 350000, "expenseCents": 2050, "balanceCents": 347950 }
}
```

- Ordenação: `date DESC, id DESC` (CA-10).
- `400` — `month` ausente ou fora do formato/intervalo (`code: "INVALID_MONTH"`).

### `GET /api/health`

- `200` — `{ "status": "ok" }`

### Outros

- Rota inexistente: `404`, `code: "NOT_FOUND"`. Erro inesperado: `500`, `code: "INTERNAL_ERROR"`, mensagem genérica e detalhes apenas no log.

## 6. Regras de conversão monetária (borda)

- **Entrada** (`parseAmountToCents`): remove espaços e o prefixo `R$`; se houver vírgula, ela é o separador decimal e pontos são separadores de milhar; sem vírgula, pontos seguidos de grupos de exatamente 3 dígitos são separadores de milhar ("1.000" → R$ 1.000,00) e qualquer outro ponto único é decimal ("10.5" → R$ 10,50). Aceita até 2 casas; completa com zeros ("0,1" → 10). Conversão feita por manipulação de string; nunca `parseFloat`.
- **Saída** (`formatCents`): `Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' })` aplicado a `cents / 100` apenas para exibição; saldo negativo exibido como `-R$ 50,00`.

## 7. Tratamento de erros

| Situação                         | Backend                       | Frontend                                                                                    |
| -------------------------------- | ----------------------------- | ------------------------------------------------------------------------------------------- |
| Campo inválido                   | `400 VALIDATION_ERROR`        | Mensagem no campo correspondente (`details` mapeado; `amountCents` → campo Valor)           |
| Falha de rede / 5xx / resposta inesperada | log de erro          | "Não foi possível comunicar com o servidor. Tente novamente." (`role="alert"`), campos preservados |
| Falha ao carregar o mês          | —                             | Mesma mensagem na área da listagem                                                           |

## 8. Configuração

`backend/.env.example`:

```
PORT=3000
DB_PATH=./data/finance.db
LOG_LEVEL=info
SHUTDOWN_TIMEOUT_MS=10000
```

Frontend: `BACKEND_URL` (alvo do proxy do Vite, padrão `http://localhost:3000`) e `FRONTEND_PORT` (padrão `5173`).

## 9. Conformidade com o AGENTS.md e as rules

| Fonte                          | Lido | Como a TechSpec atende                                                                 |
| ------------------------------ | ---- | -------------------------------------------------------------------------------------- |
| `AGENTS.md`                    | Sim  | Monorepo com workspaces `backend`, `frontend` e `e2e/`; scripts de lint/test/coverage/e2e |
| `rules/code-standards.md`      | Sim  | TS strict, sem `any`, componentes e funções pequenos (seção 3 já divide responsabilidades) |
| `rules/backend.md`             | Sim  | Pastas routes/services/data/types, `dotenv`, `pino`, `shutdown.ts`, queries parametrizadas, erros padronizados |
| `rules/frontend.md`            | Sim  | Pastas components/views/services/hooks/types, Tailwind, a11y, mobile-first             |
| `rules/money.md`               | Sim  | Seção 6 e D-02                                                                          |
| `rules/testing.md`             | Sim  | Seção 11; cobertura mínima 80%                                                          |

## 10. Conformidade com skills

Não há skills do projeto em `.agents/skills/`. Nenhum desvio a registrar.

**Desvio de rule registrado:** `CATEGORIES` e os tipos de transação existem em `backend/src/types` e em `frontend/src/types` (duplicação). Justificativa: dois workspaces independentes sem pacote compartilhado; a lista é pequena e estável, e os testes E2E garantem que as categorias do formulário são aceitas pela API.

## 11. Abordagem de testes

Meta: cobertura ≥ 80% (linhas, funções, branches, statements) por workspace, conforme `rules/testing.md`.

### Unidade — backend (Vitest)

| ID    | Caso                                                                                          | CA                 |
| ----- | --------------------------------------------------------------------------------------------- | ------------------ |
| TU-01 | `validateNewTransaction` aceita entrada válida e remove espaços da descrição                  | CA-01              |
| TU-02 | Rejeita cada campo ausente com erro no campo correspondente                                   | CA-03, CA-08       |
| TU-03 | Rejeita `amountCents` zero e negativo                                                          | CA-04, CA-08       |
| TU-04 | Rejeita `amountCents` não inteiro, string e acima do máximo                                    | CA-05, CA-08       |
| TU-05 | Rejeita descrição vazia, só com espaços e com mais de 120 caracteres                           | CA-06, CA-08       |
| TU-06 | Rejeita data inexistente (`2026-02-31`) e formatos inválidos                                   | CA-07, CA-08       |
| TU-07 | Rejeita tipo e categoria fora da lista                                                         | CA-07, CA-08       |
| TU-08 | `parseMonth` valida `YYYY-MM` e calcula o intervalo, inclusive dezembro → janeiro              | CA-09, CA-16       |
| TU-09 | `getMonthly` monta o resumo com saldo = receitas − despesas, inclusive negativo                | CA-12, CA-14       |

### Unidade — frontend (Vitest + Testing Library)

| ID    | Caso                                                                                          | CA                 |
| ----- | --------------------------------------------------------------------------------------------- | ------------------ |
| TU-10 | `parseAmountToCents` converte "0,10"→10, "0,1"→10, "1.234,56"→123456, "10"→1000, "R$ 5,00"→500 | CA-13              |
| TU-11 | `parseAmountToCents` rejeita "", "abc", "0", "-5", "1,234", acima do máximo                    | CA-04, CA-05       |
| TU-12 | `formatCents` exibe "R$ 0,30", "R$ 0,00" e "-R$ 50,00"                                          | CA-12–CA-14, CA-17 |
| TU-13 | `validateForm` retorna as mensagens do PRD por campo                                           | CA-03–CA-07        |
| TU-14 | Utilitários de data: mês atual com relógio controlado, `shiftMonth`, `formatDate` dd/mm/aaaa    | CA-09, CA-15, CA-16 |
| TU-15 | `TransactionForm` exibe erros por campo com `aria-invalid`/`aria-describedby` e não envia       | CA-03, CA-04, CA-25 |
| TU-16 | `TransactionForm` envia valores em centavos e volta ao estado inicial após sucesso              | CA-01              |
| TU-17 | `SummaryCards` exibe totais e indica saldo negativo em texto                                    | CA-12, CA-14       |
| TU-18 | `TransactionList` mostra estado vazio e todos os dados de cada item com tipo textual            | CA-09, CA-11, CA-17 |
| TU-19 | `MonthSelector` navega para mês anterior/próximo e aceita mês digitado                          | CA-16              |
| TU-20 | `transactionsApi` converte 400 em `ApiValidationError` e rede/5xx em `ApiConnectionError`       | CA-08, CA-20       |
| TU-21 | `FinanceView`: após cadastro seleciona o mês do lançamento; em falha mostra erro e preserva campos | CA-02, CA-20, CA-21 |

### Integração — backend (Vitest + Supertest, SQLite em arquivo temporário)

| ID    | Caso                                                                                          | CA                 |
| ----- | --------------------------------------------------------------------------------------------- | ------------------ |
| TI-01 | `POST` válido retorna 201 com o lançamento e o persiste                                        | CA-01              |
| TI-02 | `POST` inválido (campos vazios, valor 0/negativo/decimal, data inexistente, categoria inválida) retorna 400 padronizado e não grava | CA-08 |
| TI-03 | `GET` retorna apenas o mês pedido, na ordem `date DESC, id DESC`                                | CA-09, CA-10       |
| TI-04 | Resumo exato: receitas 10 + 20 centavos = 30; saldo negativo                                    | CA-12–CA-14        |
| TI-05 | Mês vazio retorna lista vazia e resumo zerado                                                   | CA-17              |
| TI-06 | `month` ausente ou inválido retorna 400 `INVALID_MONTH`                                         | CA-16              |
| TI-07 | Fechar e reabrir o banco no mesmo arquivo mantém os lançamentos                                 | CA-19              |
| TI-08 | JSON malformado → 400; rota inexistente → 404; erro inesperado → 500 sem detalhes internos      | CA-08, CA-20       |
| TI-09 | `registerShutdown` fecha servidor e banco ao receber o sinal                                    | CA-19              |
| TI-10 | `GET` de um mês com 1.000 lançamentos responde em menos de 1 s                                  | CA-27              |

### E2E (Playwright, pasta `e2e/`, banco temporário)

| ID     | Caso                                                                                          | CA                         |
| ------ | --------------------------------------------------------------------------------------------- | -------------------------- |
| E2E-01 | Cadastrar receita e despesa: mensagem de sucesso, formulário limpo, listagem e resumo atualizados | CA-01, CA-02, CA-09, CA-11, CA-12 |
| E2E-02 | Formulário bloqueia campos vazios, valor zero e negativo com mensagem por campo                 | CA-03–CA-05                |
| E2E-03 | API chamada diretamente rejeita lançamentos inválidos com 400                                    | CA-08                      |
| E2E-04 | 0,10 + 0,20 resulta em R$ 0,30; saldo negativo exibido com sinal                                 | CA-13, CA-14               |
| E2E-05 | Mês atual selecionado ao abrir; troca de mês; mês vazio com totais zerados                      | CA-15–CA-17                |
| E2E-06 | Dados mantidos após recarregar a página e após reiniciar o backend                               | CA-18, CA-19               |
| E2E-07 | Falha da API exibe mensagem de erro anunciada e preserva os dados digitados                     | CA-20, CA-21               |
| E2E-08 | Sem rolagem horizontal em 320 px e 1440 px, com todas as áreas visíveis                         | CA-22, CA-23               |
| E2E-09 | Cadastro e troca de mês concluídos apenas com teclado                                            | CA-24, CA-25               |
| E2E-10 | Verificação automática de acessibilidade (axe) sem violações sérias, incluindo contraste         | CA-25, CA-26               |

## 12. Riscos técnicos

| Risco                                                        | Mitigação                                                               |
| ------------------------------------------------------------ | ----------------------------------------------------------------------- |
| `node:sqlite` ainda marcado como experimental no Node 22      | API mínima isolada em `data/`; trocar de driver afeta só essa camada     |
| Fuso horário alterar o "mês atual"                            | Mês calculado no cliente pelo relógio local (premissa P-4); datas sem hora |
