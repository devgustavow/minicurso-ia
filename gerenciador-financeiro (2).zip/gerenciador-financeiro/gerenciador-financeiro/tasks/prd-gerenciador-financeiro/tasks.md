# Tarefas — Gerenciador Financeiro Pessoal

Referências: [PRD](./prd.md) · [TechSpec](./techspec.md)

Cada tarefa é uma entrega incremental testável. Uma tarefa só é concluída quando `npm run lint`, `npm run typecheck` e os testes do workspace afetado passam, mantendo a cobertura mínima de 80% (`rules/testing.md`).

| Status | # | Tarefa | Depende de | Critérios |
| ------ | - | ------ | ---------- | --------- |
| [x] | 1 | [Estrutura e configuração do projeto](./task_1.md) | — | CA-22 (base) |
| [x] | 2 | [Persistência (data)](./task_2.md) | 1 | CA-09, CA-10, CA-19, CA-27 |
| [x] | 3 | [Regras de negócio e validação (services)](./task_3.md) | 2 | CA-01, CA-03–CA-08, CA-12, CA-14, CA-16 |
| [x] | 4 | [Rotas da API](./task_4.md) | 3 | CA-01, CA-08–CA-10, CA-12–CA-14, CA-16, CA-17 |
| [x] | 5 | [Serviços, utilitários e hooks do frontend](./task_5.md) | 4 | CA-02–CA-07, CA-13–CA-16, CA-20 |
| [x] | 6 | [Componentes e tela](./task_6.md) | 5 | CA-01–CA-04, CA-09, CA-11, CA-12, CA-14–CA-17, CA-20–CA-26 |
| [x] | 7 | [Testes E2E](./task_7.md) | 6 | CA-01–CA-26 |

## Rastreabilidade dos casos de teste

| Tarefa | Casos |
| ------ | ----- |
| 1 | TI-08 (parte 404/500), TI-09 |
| 2 | TI-07, TI-10 |
| 3 | TU-01, TU-02, TU-03, TU-04, TU-05, TU-06, TU-07, TU-08, TU-09 |
| 4 | TI-01, TI-02, TI-03, TI-04, TI-05, TI-06, TI-08 |
| 5 | TU-10, TU-11, TU-12, TU-13, TU-14, TU-20 |
| 6 | TU-15, TU-16, TU-17, TU-18, TU-19, TU-21 |
| 7 | E2E-01, E2E-02, E2E-03, E2E-04, E2E-05, E2E-06, E2E-07, E2E-08, E2E-09, E2E-10 |
