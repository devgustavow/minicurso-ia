# Tarefa 7 — Testes E2E

| Campo       | Valor |
| ----------- | ----- |
| Status      | Concluída |
| Depende de  | 6 |
| Critérios   | CA-01–CA-26 |

## Entrega

Suíte Playwright em `e2e/` que sobe backend e frontend com banco temporário e cobre os fluxos do PRD.

Detalhes de implementação: [TechSpec](./techspec.md), seções 3 a 8.

## Subtarefas

- [x] 7.1 Configurar Playwright (`e2e/playwright.config.ts`) com setup/teardown que sobe backend e `vite preview` em portas livres e banco temporário
- [x] 7.2 Criar helper para reiniciar o backend durante o teste de persistência
- [x] 7.3 Implementar E2E-01 a E2E-10
- [x] 7.4 Garantir que `npm run e2e` passa

## Testes (casos da TechSpec)

- [x] E2E-01
- [x] E2E-02
- [x] E2E-03
- [x] E2E-04
- [x] E2E-05
- [x] E2E-06
- [x] E2E-07
- [x] E2E-08
- [x] E2E-09
- [x] E2E-10

## Validação

- [x] `npm run lint`
- [x] `npm run typecheck`
- [x] `npm run test:coverage` (≥ 80%)
