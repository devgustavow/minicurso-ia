# Tarefa 2 — Persistência (data)

| Campo       | Valor |
| ----------- | ----- |
| Status      | Concluída |
| Depende de  | 1 |
| Critérios   | CA-09, CA-10, CA-19, CA-27 |

## Entrega

`data/database.ts` com migração idempotente e `data/transactionRepository.ts` com `insert`, `findByPeriod`, `sumByPeriod` em queries parametrizadas.

Detalhes de implementação: [TechSpec](./techspec.md), seções 3 a 8.

## Subtarefas

- [x] 2.1 Implementar `openDatabase(path)` com criação do diretório, WAL e migração da seção 4 da TechSpec
- [x] 2.2 Implementar o repositório com queries parametrizadas e ordenação `date DESC, id DESC`
- [x] 2.3 Implementar `sumByPeriod` com `SUM` de inteiros por tipo
- [x] 2.4 Testar persistência ao reabrir o arquivo e desempenho com 1.000 registros

## Testes (casos da TechSpec)

- [x] TI-07
- [x] TI-10

## Validação

- [x] `npm run lint`
- [x] `npm run typecheck`
- [x] `npm run test:coverage` (≥ 80%)
