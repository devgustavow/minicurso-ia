# Tarefa 5 — Serviços, utilitários e hooks do frontend

| Campo       | Valor |
| ----------- | ----- |
| Status      | Concluída |
| Depende de  | 4 |
| Critérios   | CA-02–CA-07, CA-13–CA-16, CA-20 |

## Entrega

`types/`, `utils/money.ts`, `utils/date.ts`, `utils/validation.ts`, `services/transactionsApi.ts`, `hooks/useMonthlyTransactions.ts`, `hooks/useTransactionForm.ts`.

Detalhes de implementação: [TechSpec](./techspec.md), seções 3 a 8.

## Subtarefas

- [x] 5.1 Criar tipos e `CATEGORIES` espelhando o backend
- [x] 5.2 Implementar `parseAmountToCents` e `formatCents` conforme TechSpec seção 6
- [x] 5.3 Implementar utilitários de data e `validateForm`
- [x] 5.4 Implementar `transactionsApi` com `ApiValidationError` e `ApiConnectionError`
- [x] 5.5 Implementar os hooks de dados do mês e do formulário
- [x] 5.6 Escrever os testes de unidade correspondentes

## Testes (casos da TechSpec)

- [x] TU-10
- [x] TU-11
- [x] TU-12
- [x] TU-13
- [x] TU-14
- [x] TU-20

## Validação

- [x] `npm run lint`
- [x] `npm run typecheck`
- [x] `npm run test:coverage` (≥ 80%)
