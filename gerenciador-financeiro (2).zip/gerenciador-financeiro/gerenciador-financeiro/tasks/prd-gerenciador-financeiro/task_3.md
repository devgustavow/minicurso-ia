# Tarefa 3 — Regras de negócio e validação (services)

| Campo       | Valor |
| ----------- | ----- |
| Status      | Concluída |
| Depende de  | 2 |
| Critérios   | CA-01, CA-03–CA-08, CA-12, CA-14, CA-16 |

## Entrega

`services/transactionValidation.ts`, `services/month.ts` e `services/transactionService.ts`.

Detalhes de implementação: [TechSpec](./techspec.md), seções 3 a 8.

## Subtarefas

- [x] 3.1 Implementar `validateNewTransaction` com as regras e mensagens da TechSpec seção 5
- [x] 3.2 Implementar `parseMonth` com cálculo de intervalo (inclui dezembro → janeiro)
- [x] 3.3 Implementar `createTransaction` e `getMonthly` (lista + resumo com saldo)
- [x] 3.4 Escrever os testes de unidade do backend

## Testes (casos da TechSpec)

- [x] TU-01
- [x] TU-02
- [x] TU-03
- [x] TU-04
- [x] TU-05
- [x] TU-06
- [x] TU-07
- [x] TU-08
- [x] TU-09

## Validação

- [x] `npm run lint`
- [x] `npm run typecheck`
- [x] `npm run test:coverage` (≥ 80%)
