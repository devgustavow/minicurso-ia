# Testes

## Ferramentas

- Unidade e integração: **Vitest** em `backend/` e `frontend/`.
- Integração de API: Vitest + Supertest com banco SQLite em memória ou temporário.
- Componentes: Vitest + Testing Library (jsdom).
- E2E: **Playwright**, na pasta `e2e/` na raiz, subindo backend e frontend com banco temporário.

## Organização

- Testes ao lado do código (`arquivo.test.ts`) ou em `tests/` do workspace.
- Cada teste referencia o caso da TechSpec no nome: `it('TU-03: rejeita valor zero', ...)`.

## Cobertura

- Mínimo de **80%** em linhas, funções, branches e statements em cada workspace (`npm run test:coverage` falha abaixo disso).
- Arquivos de bootstrap (`server.ts`, `main.tsx`) podem ser excluídos da cobertura.

## Regras

- Testes independentes entre si e determinísticos (sem depender da data atual sem controlá-la).
- Todo bug corrigido ganha um teste de regressão.
