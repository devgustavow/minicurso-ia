# Frontend

## Estrutura de pastas (`frontend/src/`)

| Pasta         | Responsabilidade                                                  |
| ------------- | ----------------------------------------------------------------- |
| `components/` | Componentes de apresentação reutilizáveis                          |
| `views/`      | Telas que compõem componentes e hooks                              |
| `services/`   | Comunicação com a API (HTTP)                                       |
| `hooks/`      | Hooks com estado e efeitos (dados, formulários)                    |
| `types/`      | Tipos e interfaces                                                 |

Utilitários puros (formatação, conversões) ficam em `utils/`.

## React e estilo

- Componentes funcionais com hooks. Nenhum componente acessa a API diretamente: use `services/` via `hooks/`.
- Estilo exclusivamente com Tailwind CSS; sem arquivos CSS por componente.
- Layout responsivo mobile-first, funcional a partir de 320 px de largura.

## Acessibilidade

- Todo campo de formulário tem `<label>` associado.
- Erros de campo vinculados com `aria-describedby` e `aria-invalid`.
- Mensagens de status e erro anunciadas por região `aria-live`/`role="alert"`.
- Toda funcionalidade operável apenas por teclado, com foco visível.
- Contraste mínimo WCAG AA.

## Configuração

- A URL da API vem de variável de ambiente do Vite (`VITE_API_URL`), com padrão para desenvolvimento local.
