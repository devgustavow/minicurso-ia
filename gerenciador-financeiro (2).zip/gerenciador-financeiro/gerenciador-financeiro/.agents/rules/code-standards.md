# Padrões de código

## TypeScript

- `strict: true` em todos os workspaces.
- Proibido `any` (explícito ou implícito). Use `unknown` e estreite o tipo.
- Tipos e interfaces compartilhados ficam na pasta `types/` do workspace.
- Prefira `const`, funções puras e retornos explícitos em funções exportadas.

## Limites de tamanho

| Item                     | Limite         |
| ------------------------ | -------------- |
| Arquivo                  | 200 linhas     |
| Função                   | 40 linhas      |
| Componente React         | 120 linhas     |

Ao se aproximar do limite, extraia funções, hooks ou componentes.

## Comentários

- Não escreva comentários que repetem o que o código já diz.
- Comentários são permitidos apenas para explicar o **porquê** de uma decisão não óbvia.

## Nomenclatura

- Código (identificadores) em inglês; textos exibidos para a pessoa usuária em português.
- Arquivos de componentes em `PascalCase.tsx`; demais arquivos em `camelCase.ts`.

## Lint

- ESLint com `typescript-eslint` (configuração recomendada + `no-explicit-any` como erro) em todos os workspaces.
- Nenhum aviso ou erro de lint pode ser ignorado sem justificativa no código.
