# Backend

## Estrutura de pastas (`backend/src/`)

| Pasta       | Responsabilidade                                                     |
| ----------- | -------------------------------------------------------------------- |
| `routes/`   | Rotas HTTP: lê a requisição, chama o service e monta a resposta       |
| `services/` | Regras de negócio e validação; não conhece HTTP nem SQL               |
| `data/`     | Acesso ao banco (conexão, migrações, repositórios)                    |
| `types/`    | Tipos e interfaces do domínio e dos contratos                         |

Arquivos de infraestrutura (`app.ts`, `server.ts`, `config.ts`, `logger.ts`) ficam na raiz de `src/`.

## Configuração

- Variáveis de ambiente carregadas com `dotenv` em um único módulo (`config.ts`), que valida e exporta valores tipados.
- Forneça `.env.example` com todas as variáveis e valores padrão seguros. Nunca versione `.env`.

## Logger

- Um logger centralizado (`logger.ts`). Proibido `console.*` no código da aplicação.
- Logue início/encerramento do servidor, erros inesperados e cada requisição (método, rota, status, duração).

## Graceful shutdown

- Trate `SIGINT` e `SIGTERM`: pare de aceitar conexões, finalize as requisições em andamento, feche o banco e encerre com código 0.
- Defina um tempo limite para o encerramento forçado.

## Banco de dados

- Toda query é parametrizada. Proibido montar SQL por concatenação ou template string com dados externos.
- Migrações idempotentes executadas na inicialização.

## API

- JSON em todas as respostas. Erros no formato padronizado `{ "error": { "code": string, "message": string, "details"?: object } }`.
- Status HTTP adequados: `201` criação, `200` leitura, `400` validação, `404` não encontrado, `500` erro inesperado (sem vazar detalhes internos).
