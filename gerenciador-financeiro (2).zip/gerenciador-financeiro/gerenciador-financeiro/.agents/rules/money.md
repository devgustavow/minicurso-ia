# Valores monetários

- Valores são armazenados, trafegados e calculados como **centavos inteiros** (`number` inteiro no TypeScript, `INTEGER` no banco).
- Proibido usar ponto flutuante para guardar ou somar dinheiro.
- A conversão de/para reais acontece **somente na borda**: ao ler o campo do formulário e ao exibir valores.
- A conversão de texto para centavos é feita por manipulação de string (sem `parseFloat` seguido de multiplicação).
- Exibição com `Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' })`.
