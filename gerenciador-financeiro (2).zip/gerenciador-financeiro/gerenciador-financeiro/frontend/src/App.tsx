import { FinanceView } from './views/FinanceView';

export default function App() {
  return <FinanceView />;
}
