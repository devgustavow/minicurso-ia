export const TRANSACTION_TYPES = ['income', 'expense'] as const;
export type TransactionType = (typeof TRANSACTION_TYPES)[number];

export const TYPE_LABELS: Record<TransactionType, string> = {
  income: 'Receita',
  expense: 'Despesa',
};

export const CATEGORIES = [
  'Salário',
  'Freelance',
  'Investimentos',
  'Alimentação',
  'Moradia',
  'Transporte',
  'Saúde',
  'Educação',
  'Lazer',
  'Outros',
] as const;
export type Category = (typeof CATEGORIES)[number];

export const MAX_AMOUNT_CENTS = 9_999_999_999;
export const MAX_DESCRIPTION_LENGTH = 120;

export interface NewTransactionPayload {
  type: TransactionType;
  description: string;
  amountCents: number;
  category: Category;
  date: string;
}

export interface Transaction extends NewTransactionPayload {
  id: number;
  createdAt: string;
}

export interface MonthlySummary {
  incomeCents: number;
  expenseCents: number;
  balanceCents: number;
}

export interface MonthlyReport {
  month: string;
  transactions: Transaction[];
  summary: MonthlySummary;
}

export interface FormValues {
  type: TransactionType | '';
  description: string;
  amount: string;
  category: Category | '';
  date: string;
}

export type FormField = keyof FormValues;
export type FormErrors = Partial<Record<FormField, string>>;

export interface StatusNotice {
  kind: 'success' | 'error';
  message: string;
}
