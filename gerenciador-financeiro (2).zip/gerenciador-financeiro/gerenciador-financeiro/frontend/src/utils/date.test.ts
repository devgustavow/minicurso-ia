import {
  currentMonth,
  formatDate,
  formatMonthLabel,
  isValidCalendarDate,
  isValidMonth,
  monthOf,
  shiftMonth,
  todayISO,
} from './date';

describe('utilitários de data', () => {
  it('TU-14: calcula mês atual e data de hoje pelo relógio local', () => {
    const now = new Date(2026, 9, 5, 23, 59);
    expect(currentMonth(now)).toBe('2026-10');
    expect(todayISO(now)).toBe('2026-10-05');
  });

  it('TU-14: usa a data atual por padrão', () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2026, 0, 31, 12));
    expect(currentMonth()).toBe('2026-01');
    expect(todayISO()).toBe('2026-01-31');
    vi.useRealTimers();
  });

  it('TU-14: desloca meses atravessando anos', () => {
    expect(shiftMonth('2026-10', 1)).toBe('2026-11');
    expect(shiftMonth('2026-12', 1)).toBe('2027-01');
    expect(shiftMonth('2026-01', -1)).toBe('2025-12');
  });

  it('TU-14: formata datas e meses em português', () => {
    expect(formatDate('2026-10-05')).toBe('05/10/2026');
    expect(formatMonthLabel('2026-10')).toBe('Outubro de 2026');
    expect(monthOf('2026-10-05')).toBe('2026-10');
  });

  it('TU-14: valida mês e data de calendário', () => {
    expect(isValidMonth('2026-10')).toBe(true);
    expect(isValidMonth('2026-13')).toBe(false);
    expect(isValidCalendarDate('2028-02-29')).toBe(true);
    expect(isValidCalendarDate('2026-02-31')).toBe(false);
    expect(isValidCalendarDate('31/02/2026')).toBe(false);
  });
});
