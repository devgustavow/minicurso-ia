import { formatCents, parseAmountToCents } from './money';

describe('parseAmountToCents', () => {
  it.each([
    ['0,10', 10],
    ['0,1', 10],
    ['0,20', 20],
    ['1.234,56', 123456],
    ['1234,56', 123456],
    ['10', 1000],
    ['10,', 1000],
    [',5', 50],
    ['10.5', 1050],
    ['R$ 5,00', 500],
    ['  7,25  ', 725],
    ['1.234.567', 123456700],
    ['99.999.999,99', 9999999999],
  ])('TU-10: converte "%s" em %i centavos', (text, cents) => {
    expect(parseAmountToCents(text)).toEqual({ ok: true, cents });
  });

  it.each([
    ['', 'Informe o valor.'],
    ['   ', 'Informe o valor.'],
    ['abc', 'Informe um valor numérico válido (ex.: 10,50).'],
    ['1,2,3', 'Informe um valor numérico válido (ex.: 10,50).'],
    ['1.2.3', 'Informe um valor numérico válido (ex.: 10,50).'],
    ['12.34,5', 'Informe um valor numérico válido (ex.: 10,50).'],
    [',', 'Informe um valor numérico válido (ex.: 10,50).'],
    ['0', 'Informe um valor maior que zero.'],
    ['0,00', 'Informe um valor maior que zero.'],
    ['-5', 'Informe um valor maior que zero.'],
    ['-0,01', 'Informe um valor maior que zero.'],
    ['1,234', 'Use no máximo 2 casas decimais.'],
    ['100000000', 'O valor máximo é R$ 99.999.999,99.'],
    ['999999999,00', 'O valor máximo é R$ 99.999.999,99.'],
  ])('TU-11: rejeita "%s"', (text, error) => {
    expect(parseAmountToCents(text)).toEqual({ ok: false, error });
  });
});

describe('parseAmountToCents — regressão QA-01', () => {
  it.each([
    ['1.000', 100000],
    ['2.500', 250000],
    ['12.345', 1234500],
    ['R$ 1.000', 100000],
  ])('QA-01: entende ponto seguido de 3 dígitos como separador de milhar ("%s")', (text, cents) => {
    expect(parseAmountToCents(text)).toEqual({ ok: true, cents });
  });
});

describe('formatCents', () => {
  it('TU-12: formata valores em reais sem erro de arredondamento', () => {
    expect(formatCents(10 + 20)).toBe('R$ 0,30');
    expect(formatCents(0)).toBe('R$ 0,00');
    expect(formatCents(123456)).toBe('R$ 1.234,56');
    expect(formatCents(-5000)).toBe('-R$ 50,00');
  });
});
