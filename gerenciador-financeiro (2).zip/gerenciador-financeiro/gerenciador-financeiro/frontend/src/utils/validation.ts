import {
  CATEGORIES,
  MAX_DESCRIPTION_LENGTH,
  TRANSACTION_TYPES,
  type Category,
  type FormErrors,
  type FormValues,
  type NewTransactionPayload,
  type TransactionType,
} from '../types/transaction';
import { isValidCalendarDate } from './date';
import { parseAmountToCents } from './money';

export type FormValidation =
  | { ok: true; payload: NewTransactionPayload }
  | { ok: false; errors: FormErrors };

function checkDescription(value: string): string | undefined {
  const trimmed = value.trim();
  if (trimmed === '') return 'Informe a descrição.';
  if (trimmed.length > MAX_DESCRIPTION_LENGTH) {
    return `A descrição deve ter no máximo ${MAX_DESCRIPTION_LENGTH} caracteres.`;
  }
  return undefined;
}

function checkDate(value: string): string | undefined {
  if (value === '') return 'Informe a data.';
  return isValidCalendarDate(value) ? undefined : 'Informe uma data válida.';
}

export function validateForm(values: FormValues): FormValidation {
  const amount = parseAmountToCents(values.amount);
  const candidates: FormErrors = {
    type: TRANSACTION_TYPES.includes(values.type as TransactionType) ? undefined : 'Selecione o tipo.',
    description: checkDescription(values.description),
    amount: amount.ok ? undefined : amount.error,
    category: CATEGORIES.includes(values.category as Category) ? undefined : 'Selecione a categoria.',
    date: checkDate(values.date),
  };
  const errors = Object.fromEntries(Object.entries(candidates).filter(([, message]) => message)) as FormErrors;
  if (Object.keys(errors).length > 0 || !amount.ok) {
    return { ok: false, errors };
  }
  return {
    ok: true,
    payload: {
      type: values.type as TransactionType,
      description: values.description.trim(),
      amountCents: amount.cents,
      category: values.category as Category,
      date: values.date,
    },
  };
}
