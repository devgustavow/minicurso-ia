import { MAX_AMOUNT_CENTS } from '../types/transaction';

export type AmountResult = { ok: true; cents: number } | { ok: false; error: string };

const INVALID = 'Informe um valor numérico válido (ex.: 10,50).';
const NOT_POSITIVE = 'Informe um valor maior que zero.';
const TOO_MANY_DECIMALS = 'Use no máximo 2 casas decimais.';
const TOO_LARGE = 'O valor máximo é R$ 99.999.999,99.';
const THOUSANDS = /^\d{1,3}(\.\d{3})+$/;

const formatter = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

function splitNumber(body: string): { integer: string; decimals: string } | null {
  const commaIndex = body.lastIndexOf(',');
  if (commaIndex >= 0) {
    const integer = body.slice(0, commaIndex);
    const valid = /^\d*$/.test(integer) || THOUSANDS.test(integer);
    return valid ? { integer: integer.replaceAll('.', ''), decimals: body.slice(commaIndex + 1) } : null;
  }
  if (THOUSANDS.test(body)) {
    return { integer: body.replaceAll('.', ''), decimals: '' };
  }
  const [integer = '', decimals = '', ...rest] = body.split('.');
  return rest.length > 0 ? null : { integer, decimals };
}

export function parseAmountToCents(text: string): AmountResult {
  const cleaned = text.trim().replace(/^R\$/, '').replace(/\s/g, '');
  if (cleaned === '') {
    return { ok: false, error: 'Informe o valor.' };
  }
  const negative = cleaned.startsWith('-');
  const parts = splitNumber(negative ? cleaned.slice(1) : cleaned);
  if (!parts || !/^\d*$/.test(`${parts.integer}${parts.decimals}`) || `${parts.integer}${parts.decimals}` === '') {
    return { ok: false, error: INVALID };
  }
  if (parts.decimals.length > 2) {
    return { ok: false, error: TOO_MANY_DECIMALS };
  }
  if (parts.integer.replace(/^0+/, '').length > 8) {
    return { ok: false, error: TOO_LARGE };
  }
  const cents = Number(parts.integer || '0') * 100 + Number(parts.decimals.padEnd(2, '0'));
  if (negative || cents === 0) {
    return { ok: false, error: NOT_POSITIVE };
  }
  return cents > MAX_AMOUNT_CENTS ? { ok: false, error: TOO_LARGE } : { ok: true, cents };
}

export function formatCents(cents: number): string {
  return formatter.format(cents / 100).replace(/\s/g, ' ');
}
