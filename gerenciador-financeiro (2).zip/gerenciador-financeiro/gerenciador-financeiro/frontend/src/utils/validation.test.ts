import type { FormValues } from '../types/transaction';
import { validateForm } from './validation';

const valid: FormValues = {
  type: 'expense',
  description: '  Mercado  ',
  amount: '20,50',
  category: 'Alimentação',
  date: '2026-10-10',
};

describe('validateForm', () => {
  it('TU-13: converte valores válidos para o payload da API', () => {
    expect(validateForm(valid)).toEqual({
      ok: true,
      payload: { type: 'expense', description: 'Mercado', amountCents: 2050, category: 'Alimentação', date: '2026-10-10' },
    });
  });

  it('TU-13: retorna uma mensagem por campo vazio', () => {
    expect(validateForm({ type: '', description: ' ', amount: '', category: '', date: '' })).toEqual({
      ok: false,
      errors: {
        type: 'Selecione o tipo.',
        description: 'Informe a descrição.',
        amount: 'Informe o valor.',
        category: 'Selecione a categoria.',
        date: 'Informe a data.',
      },
    });
  });

  it('TU-13: rejeita valor zero ou negativo, descrição longa e data inexistente', () => {
    expect(validateForm({ ...valid, amount: '0' })).toEqual({ ok: false, errors: { amount: 'Informe um valor maior que zero.' } });
    expect(validateForm({ ...valid, amount: '-3' })).toEqual({ ok: false, errors: { amount: 'Informe um valor maior que zero.' } });
    expect(validateForm({ ...valid, description: 'x'.repeat(121) })).toEqual({
      ok: false,
      errors: { description: 'A descrição deve ter no máximo 120 caracteres.' },
    });
    expect(validateForm({ ...valid, date: '2026-02-31' })).toEqual({ ok: false, errors: { date: 'Informe uma data válida.' } });
  });
});
