import { useState } from 'react';
import { MonthSelector } from '../components/MonthSelector';
import { StatusMessage } from '../components/StatusMessage';
import { SummaryCards } from '../components/SummaryCards';
import { TransactionForm } from '../components/TransactionForm';
import { TransactionList } from '../components/TransactionList';
import { useMonthlyTransactions } from '../hooks/useMonthlyTransactions';
import { useTransactionForm } from '../hooks/useTransactionForm';
import type { MonthlySummary, Transaction } from '../types/transaction';
import { currentMonth, monthOf } from '../utils/date';

const EMPTY_SUMMARY: MonthlySummary = { incomeCents: 0, expenseCents: 0, balanceCents: 0 };

export function FinanceView() {
  const [month, setMonth] = useState(() => currentMonth());
  const { report, loading, error, reload } = useMonthlyTransactions(month);

  const handleCreated = (transaction: Transaction) => {
    const target = monthOf(transaction.date);
    if (target === month) reload();
    else setMonth(target);
  };
  const form = useTransactionForm(handleCreated);

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:py-10">
      <header className="mb-6">
        <h1 className="text-sm font-bold text-accent">Gerenciador Financeiro</h1>
      </header>
      <main className="space-y-6">
        <section aria-label="Mês consultado" className="space-y-4">
          <MonthSelector month={month} onChange={setMonth} />
          <SummaryCards summary={report?.summary ?? EMPTY_SUMMARY} />
        </section>
        <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,22rem)_1fr]">
          <div className="space-y-3 rounded-lg border border-line bg-sheet p-5 lg:sticky lg:top-6">
            <StatusMessage status={form.status} />
            <TransactionForm
              values={form.values}
              errors={form.errors}
              submitting={form.submitting}
              onChange={form.setField}
              onSubmit={form.submit}
            />
          </div>
          <div className="rounded-lg border border-line bg-sheet p-5">
            <TransactionList transactions={report?.transactions ?? []} loading={loading} error={error} />
          </div>
        </div>
      </main>
    </div>
  );
}
