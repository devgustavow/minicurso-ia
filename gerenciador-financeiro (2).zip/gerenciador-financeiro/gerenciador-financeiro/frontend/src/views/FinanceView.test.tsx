import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import * as api from '../services/transactionsApi';
import type { MonthlyReport, Transaction } from '../types/transaction';
import { FinanceView } from './FinanceView';

function reportFor(month: string, transactions: Transaction[] = []): MonthlyReport {
  const income = transactions.filter((t) => t.type === 'income').reduce((sum, t) => sum + t.amountCents, 0);
  const expense = transactions.filter((t) => t.type === 'expense').reduce((sum, t) => sum + t.amountCents, 0);
  return { month, transactions, summary: { incomeCents: income, expenseCents: expense, balanceCents: income - expense } };
}

async function fillForm(date: string) {
  await userEvent.click(screen.getByRole('radio', { name: 'Receita' }));
  await userEvent.type(screen.getByLabelText('Descrição'), 'Freela');
  await userEvent.type(screen.getByLabelText('Valor (R$)'), '0,10');
  await userEvent.selectOptions(screen.getByLabelText('Categoria'), 'Freelance');
  const dateInput = screen.getByLabelText('Data');
  await userEvent.clear(dateInput);
  await userEvent.type(dateInput, date);
}

describe('FinanceView', () => {
  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date(2026, 9, 15, 10));
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it('TU-21: após cadastro seleciona o mês do lançamento e mostra sucesso', async () => {
    const saved: Transaction = { id: 1, type: 'income', description: 'Freela', amountCents: 10, category: 'Freelance', date: '2026-09-20', createdAt: '' };
    const fetchSpy = vi.spyOn(api, 'fetchMonthly').mockImplementation(async (month) => reportFor(month, month === '2026-09' ? [saved] : []));
    const createSpy = vi.spyOn(api, 'createTransaction').mockResolvedValue(saved);
    render(<FinanceView />);
    expect(await screen.findByRole('heading', { name: 'Outubro de 2026' })).toBeInTheDocument();

    await fillForm('2026-09-20');
    await userEvent.click(screen.getByRole('button', { name: 'Adicionar lançamento' }));

    expect(createSpy).toHaveBeenCalledWith({ type: 'income', description: 'Freela', amountCents: 10, category: 'Freelance', date: '2026-09-20' });
    expect(await screen.findByRole('status')).toHaveTextContent('Lançamento cadastrado com sucesso.');
    expect(screen.getByRole('heading', { name: 'Setembro de 2026' })).toBeInTheDocument();
    const list = await screen.findByRole('list', { name: 'Lançamentos' });
    expect(within(list).getByText('Freela')).toBeInTheDocument();
    expect(screen.getByTestId('receitas')).toHaveTextContent('R$ 0,10');
    expect(screen.getByLabelText('Descrição')).toHaveValue('');
    expect(fetchSpy).toHaveBeenCalledWith('2026-09');
  });

  it('TU-21: recarrega o mesmo mês quando o lançamento é do mês exibido', async () => {
    const saved: Transaction = { id: 1, type: 'income', description: 'Freela', amountCents: 10, category: 'Freelance', date: '2026-10-02', createdAt: '' };
    const fetchSpy = vi.spyOn(api, 'fetchMonthly').mockResolvedValue(reportFor('2026-10'));
    vi.spyOn(api, 'createTransaction').mockResolvedValue(saved);
    render(<FinanceView />);
    await screen.findByText('Nenhum lançamento neste mês.');
    await fillForm('2026-10-02');
    await userEvent.click(screen.getByRole('button', { name: 'Adicionar lançamento' }));
    await waitFor(() => expect(fetchSpy).toHaveBeenCalledTimes(2));
  });

  it('TU-21: falha de comunicação mostra alerta e preserva os campos', async () => {
    vi.spyOn(api, 'fetchMonthly').mockResolvedValue(reportFor('2026-10'));
    vi.spyOn(api, 'createTransaction').mockRejectedValue(new api.ApiConnectionError());
    render(<FinanceView />);
    await fillForm('2026-10-02');
    await userEvent.click(screen.getByRole('button', { name: 'Adicionar lançamento' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Não foi possível comunicar com o servidor. Tente novamente.');
    expect(screen.getByLabelText('Descrição')).toHaveValue('Freela');
    expect(screen.getByLabelText('Valor (R$)')).toHaveValue('0,10');
  });

  it('troca de mês pelo seletor e mostra totais zerados em mês vazio', async () => {
    vi.spyOn(api, 'fetchMonthly').mockImplementation(async (month) => reportFor(month));
    render(<FinanceView />);
    await userEvent.click(await screen.findByRole('button', { name: 'Próximo mês' }));
    expect(await screen.findByRole('heading', { name: 'Novembro de 2026' })).toBeInTheDocument();
    expect(await screen.findByText('Nenhum lançamento neste mês.')).toBeInTheDocument();
    expect(screen.getByTestId('saldo')).toHaveTextContent('R$ 0,00');
  });
});
