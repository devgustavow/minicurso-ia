import { render, screen } from '@testing-library/react';
import App from './App';
import * as api from './services/transactionsApi';

describe('App', () => {
  it('renderiza a tela principal', async () => {
    vi.spyOn(api, 'fetchMonthly').mockResolvedValue({
      month: '2026-10',
      transactions: [],
      summary: { incomeCents: 0, expenseCents: 0, balanceCents: 0 },
    });
    render(<App />);
    expect(screen.getByRole('heading', { level: 1, name: 'Gerenciador Financeiro' })).toBeInTheDocument();
    expect(await screen.findByText('Nenhum lançamento neste mês.')).toBeInTheDocument();
    vi.restoreAllMocks();
  });
});
