import { ApiConnectionError, ApiValidationError, createTransaction, fetchMonthly } from './transactionsApi';

const payload = { type: 'income', description: 'Salário', amountCents: 100, category: 'Salário', date: '2026-10-01' } as const;

function mockFetch(response: Partial<Response> | Error) {
  const fn = vi.fn(() => (response instanceof Error ? Promise.reject(response) : Promise.resolve(response as Response)));
  vi.stubGlobal('fetch', fn);
  return fn;
}

function jsonResponse(status: number, body: unknown): Partial<Response> {
  return { ok: status >= 200 && status < 300, status, json: () => Promise.resolve(body) };
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('transactionsApi', () => {
  it('envia o cadastro como JSON e devolve o lançamento criado', async () => {
    const fetchMock = mockFetch(jsonResponse(201, { id: 1, ...payload }));
    await expect(createTransaction(payload)).resolves.toMatchObject({ id: 1 });
    expect(fetchMock).toHaveBeenCalledWith('/api/transactions', expect.objectContaining({ method: 'POST', body: JSON.stringify(payload) }));
  });

  it('busca o mês pedido', async () => {
    const fetchMock = mockFetch(jsonResponse(200, { month: '2026-10', transactions: [], summary: {} }));
    await expect(fetchMonthly('2026-10')).resolves.toMatchObject({ month: '2026-10' });
    expect(fetchMock).toHaveBeenCalledWith('/api/transactions?month=2026-10', expect.anything());
  });

  it('TU-20: converte 400 de validação em ApiValidationError com detalhes', async () => {
    mockFetch(jsonResponse(400, { error: { code: 'VALIDATION_ERROR', details: { amountCents: 'Informe um valor maior que zero.' } } }));
    const error = await createTransaction(payload).catch((cause: unknown) => cause);
    expect(error).toBeInstanceOf(ApiValidationError);
    expect((error as ApiValidationError).details).toEqual({ amountCents: 'Informe um valor maior que zero.' });
  });

  it.each([
    ['falha de rede', new TypeError('Failed to fetch')],
    ['erro 500', jsonResponse(500, { error: { code: 'INTERNAL_ERROR' } })],
    ['400 sem detalhes', jsonResponse(400, { error: { code: 'INVALID_MONTH' } })],
    ['resposta não JSON', { ok: false, status: 502, json: () => Promise.reject(new SyntaxError('x')) }],
  ])('TU-20: converte %s em ApiConnectionError', async (_name, response) => {
    mockFetch(response as Partial<Response> | Error);
    await expect(fetchMonthly('2026-10')).rejects.toBeInstanceOf(ApiConnectionError);
  });
});
