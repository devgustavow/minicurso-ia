import type { MonthlyReport, NewTransactionPayload, Transaction } from '../types/transaction';

export const API_BASE_URL = (import.meta.env.VITE_API_URL ?? '').replace(/\/$/, '');

export const CONNECTION_ERROR_MESSAGE = 'Não foi possível comunicar com o servidor. Tente novamente.';

export class ApiValidationError extends Error {
  constructor(readonly details: Record<string, string>) {
    super('Dados inválidos.');
    this.name = 'ApiValidationError';
  }
}

export class ApiConnectionError extends Error {
  constructor() {
    super(CONNECTION_ERROR_MESSAGE);
    this.name = 'ApiConnectionError';
  }
}

interface ErrorBody {
  error?: { code?: string; details?: Record<string, string> };
}

async function readJson(response: Response): Promise<unknown> {
  try {
    return await response.json();
  } catch {
    throw new ApiConnectionError();
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, { ...init, headers: { 'Content-Type': 'application/json', ...init?.headers } });
  } catch {
    throw new ApiConnectionError();
  }
  const body = await readJson(response);
  if (response.ok) {
    return body as T;
  }
  const error = (body as ErrorBody).error;
  if (response.status === 400 && error?.code === 'VALIDATION_ERROR' && error.details) {
    throw new ApiValidationError(error.details);
  }
  throw new ApiConnectionError();
}

export function createTransaction(payload: NewTransactionPayload): Promise<Transaction> {
  return request<Transaction>('/api/transactions', { method: 'POST', body: JSON.stringify(payload) });
}

export function fetchMonthly(month: string): Promise<MonthlyReport> {
  return request<MonthlyReport>(`/api/transactions?month=${encodeURIComponent(month)}`);
}
