import { fireEvent, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { useState } from 'react';
import type { FormErrors, FormValues, Transaction } from '../types/transaction';
import { MonthSelector } from './MonthSelector';
import { StatusMessage } from './StatusMessage';
import { SummaryCards } from './SummaryCards';
import { TransactionForm } from './TransactionForm';
import { TransactionList } from './TransactionList';

const emptyValues: FormValues = { type: '', description: '', amount: '', category: '', date: '' };

describe('TransactionForm', () => {
  it('TU-15: exibe erros por campo com aria-invalid/aria-describedby e foca o primeiro', async () => {
    const errors: FormErrors = { type: 'Selecione o tipo.', description: 'Informe a descrição.', amount: 'Informe um valor maior que zero.' };
    function Harness() {
      const [shown, setShown] = useState<FormErrors>({});
      return (
        <TransactionForm values={emptyValues} errors={shown} submitting={false} onChange={vi.fn()} onSubmit={(e) => { e.preventDefault(); setShown(errors); }} />
      );
    }
    render(<Harness />);
    await userEvent.click(screen.getByRole('button', { name: 'Adicionar lançamento' }));
    const description = screen.getByLabelText('Descrição');
    expect(description).toHaveAttribute('aria-invalid', 'true');
    expect(description).toHaveAccessibleDescription('Informe a descrição.');
    expect(screen.getByLabelText('Valor (R$)')).toHaveAccessibleDescription('Informe um valor maior que zero.');
    expect(screen.getByRole('group', { name: 'Tipo' })).toHaveAccessibleDescription('Selecione o tipo.');
    expect(screen.getByRole('radio', { name: 'Receita' })).toHaveFocus();
  });

  it('TU-16: repassa cada alteração e o envio', async () => {
    const onChange = vi.fn();
    const onSubmit = vi.fn((event: { preventDefault: () => void }) => event.preventDefault());
    render(<TransactionForm values={emptyValues} errors={{}} submitting={false} onChange={onChange} onSubmit={onSubmit} />);
    await userEvent.click(screen.getByRole('radio', { name: 'Despesa' }));
    await userEvent.type(screen.getByLabelText('Descrição'), 'M');
    await userEvent.type(screen.getByLabelText('Valor (R$)'), '5');
    await userEvent.selectOptions(screen.getByLabelText('Categoria'), 'Lazer');
    await userEvent.type(screen.getByLabelText('Data'), '2026-10-01');
    await userEvent.click(screen.getByRole('button', { name: 'Adicionar lançamento' }));
    expect(onChange).toHaveBeenCalledWith('type', 'expense');
    expect(onChange).toHaveBeenCalledWith('description', 'M');
    expect(onChange).toHaveBeenCalledWith('amount', '5');
    expect(onChange).toHaveBeenCalledWith('category', 'Lazer');
    expect(onChange).toHaveBeenCalledWith('date', '2026-10-01');
    expect(onSubmit).toHaveBeenCalledOnce();
  });

  it('desabilita o botão durante o envio', () => {
    render(<TransactionForm values={emptyValues} errors={{}} submitting onChange={vi.fn()} onSubmit={vi.fn()} />);
    expect(screen.getByRole('button', { name: 'Salvando…' })).toBeDisabled();
  });
});

describe('SummaryCards', () => {
  it('TU-17: exibe totais e indica saldo negativo em texto', () => {
    render(<SummaryCards summary={{ incomeCents: 30, expenseCents: 5030, balanceCents: -5000 }} />);
    expect(screen.getByTestId('receitas')).toHaveTextContent('R$ 0,30');
    expect(screen.getByTestId('despesas')).toHaveTextContent('R$ 50,30');
    expect(screen.getByTestId('saldo')).toHaveTextContent('-R$ 50,00');
    expect(screen.getByText(/Saldo negativo/)).toBeInTheDocument();
  });

  it('TU-17: saldo positivo não exibe alerta', () => {
    render(<SummaryCards summary={{ incomeCents: 100, expenseCents: 0, balanceCents: 100 }} />);
    expect(screen.queryByText(/Saldo negativo/)).not.toBeInTheDocument();
  });
});

describe('TransactionList', () => {
  const items: Transaction[] = [
    { id: 2, type: 'expense', description: 'Mercado', amountCents: 2050, category: 'Alimentação', date: '2026-10-10', createdAt: '' },
    { id: 1, type: 'income', description: 'Salário', amountCents: 350000, category: 'Salário', date: '2026-10-05', createdAt: '' },
  ];

  it('TU-18: mostra estado vazio', () => {
    render(<TransactionList transactions={[]} loading={false} error={null} />);
    expect(screen.getByText('Nenhum lançamento neste mês.')).toBeInTheDocument();
  });

  it('TU-18: mostra todos os dados de cada item com o tipo em texto', () => {
    render(<TransactionList transactions={items} loading={false} error={null} />);
    const rows = screen.getAllByRole('listitem');
    expect(rows).toHaveLength(2);
    expect(rows[0]).toHaveTextContent('Mercado');
    expect(rows[0]).toHaveTextContent('R$ 20,50');
    expect(rows[0]).toHaveTextContent('Despesa');
    expect(rows[0]).toHaveTextContent('Alimentação');
    expect(rows[0]).toHaveTextContent('10/10/2026');
    expect(rows[1]).toHaveTextContent('Receita');
  });

  it('mostra carregamento e erro', () => {
    const { rerender } = render(<TransactionList transactions={[]} loading error={null} />);
    expect(screen.getByText('Carregando lançamentos…')).toBeInTheDocument();
    rerender(<TransactionList transactions={[]} loading={false} error="Falhou." />);
    expect(screen.getByRole('alert')).toHaveTextContent('Falhou.');
  });
});

describe('MonthSelector', () => {
  it('TU-19: navega para mês anterior, próximo e digitado', async () => {
    const onChange = vi.fn();
    render(<MonthSelector month="2026-01" onChange={onChange} />);
    expect(screen.getByRole('heading', { name: 'Janeiro de 2026' })).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Mês anterior' }));
    expect(onChange).toHaveBeenLastCalledWith('2025-12');
    await userEvent.click(screen.getByRole('button', { name: 'Próximo mês' }));
    expect(onChange).toHaveBeenLastCalledWith('2026-02');
    const input = screen.getByLabelText('Ir para o mês');
    fireEvent.change(input, { target: { value: '2026-07' } });
    expect(onChange).toHaveBeenLastCalledWith('2026-07');
    onChange.mockClear();
    fireEvent.change(input, { target: { value: '' } });
    expect(onChange).not.toHaveBeenCalled();
  });
});

describe('StatusMessage', () => {
  it('anuncia sucesso em região polite e erro como alerta', () => {
    const { rerender } = render(<StatusMessage status={{ kind: 'success', message: 'Ok.' }} />);
    expect(screen.getByRole('status')).toHaveTextContent('Ok.');
    rerender(<StatusMessage status={{ kind: 'error', message: 'Erro.' }} />);
    expect(screen.getByRole('alert')).toHaveTextContent('Erro.');
    expect(screen.getByRole('status')).toBeEmptyDOMElement();
  });
});
