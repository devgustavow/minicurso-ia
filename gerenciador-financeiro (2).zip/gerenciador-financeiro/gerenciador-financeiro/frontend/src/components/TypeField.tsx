import { TRANSACTION_TYPES, TYPE_LABELS, type TransactionType } from '../types/transaction';
import { FieldError, errorId } from './FormField';

interface TypeFieldProps {
  value: TransactionType | '';
  error?: string;
  onChange: (value: TransactionType) => void;
}

const SELECTED: Record<TransactionType, string> = {
  income: 'has-[:checked]:border-income has-[:checked]:bg-income-soft has-[:checked]:text-income',
  expense: 'has-[:checked]:border-expense has-[:checked]:bg-expense-soft has-[:checked]:text-expense',
};

export function TypeField({ value, error, onChange }: TypeFieldProps) {
  return (
    <fieldset aria-describedby={error ? errorId('tipo') : undefined}>
      <legend className="text-sm font-semibold text-ink">Tipo</legend>
      <div className="mt-1 grid grid-cols-2 gap-2">
        {TRANSACTION_TYPES.map((type, index) => (
          <label
            key={type}
            className={`flex cursor-pointer items-center justify-center gap-2 rounded-md border border-line bg-sheet px-3 py-2 font-semibold has-[:focus-visible]:outline-3 has-[:focus-visible]:outline-accent ${SELECTED[type]}`}
          >
            <input
              type="radio"
              name="tipo"
              id={index === 0 ? 'tipo' : undefined}
              value={type}
              checked={value === type}
              onChange={() => onChange(type)}
              aria-invalid={Boolean(error)}
              className="size-4 accent-current"
            />
            {TYPE_LABELS[type]}
          </label>
        ))}
      </div>
      <FieldError id="tipo" message={error} />
    </fieldset>
  );
}
