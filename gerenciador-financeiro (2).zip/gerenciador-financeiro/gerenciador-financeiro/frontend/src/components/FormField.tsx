import type { ReactNode } from 'react';

export interface FieldAria {
  id: string;
  'aria-invalid': boolean;
  'aria-describedby'?: string;
}

interface FormFieldProps {
  id: string;
  label: string;
  error?: string;
  children: (aria: FieldAria) => ReactNode;
}

export function errorId(id: string): string {
  return `${id}-erro`;
}

export const inputClass =
  'mt-1 block w-full rounded-md border border-line bg-sheet px-3 py-2 text-base text-ink ' +
  'aria-[invalid=true]:border-expense aria-[invalid=true]:ring-1 aria-[invalid=true]:ring-expense';

export function FieldError({ id, message }: { id: string; message?: string }) {
  if (!message) return null;
  return (
    <p id={errorId(id)} className="mt-1 text-sm font-medium text-expense">
      {message}
    </p>
  );
}

export function FormField({ id, label, error, children }: FormFieldProps) {
  const aria: FieldAria = {
    id,
    'aria-invalid': Boolean(error),
    'aria-describedby': error ? errorId(id) : undefined,
  };
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-semibold text-ink">
        {label}
      </label>
      {children(aria)}
      <FieldError id={id} message={error} />
    </div>
  );
}
