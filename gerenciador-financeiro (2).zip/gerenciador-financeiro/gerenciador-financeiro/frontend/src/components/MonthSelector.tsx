import { formatMonthLabel, isValidMonth, shiftMonth } from '../utils/date';

interface MonthSelectorProps {
  month: string;
  onChange: (month: string) => void;
}

const arrowButton =
  'grid size-11 shrink-0 place-items-center rounded-full border border-line bg-sheet text-xl text-accent hover:bg-paper';

export function MonthSelector({ month, onChange }: MonthSelectorProps) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3">
        <button type="button" className={arrowButton} aria-label="Mês anterior" onClick={() => onChange(shiftMonth(month, -1))}>
          <span aria-hidden="true">‹</span>
        </button>
        <h2 className="min-w-0 text-2xl font-bold sm:text-3xl" aria-live="polite">
          {formatMonthLabel(month)}
        </h2>
        <button type="button" className={arrowButton} aria-label="Próximo mês" onClick={() => onChange(shiftMonth(month, 1))}>
          <span aria-hidden="true">›</span>
        </button>
      </div>
      <label className="flex items-center gap-2 text-sm font-semibold text-muted">
        Ir para o mês
        <input
          type="month"
          value={month}
          onChange={(event) => {
            if (isValidMonth(event.target.value)) onChange(event.target.value);
          }}
          className="rounded-md border border-line bg-sheet px-2 py-1.5 text-base text-ink"
        />
      </label>
    </div>
  );
}
