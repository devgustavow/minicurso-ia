import { useEffect, useRef, type FormEvent } from 'react';
import { CATEGORIES, MAX_DESCRIPTION_LENGTH, type FormErrors, type FormField as Field, type FormValues } from '../types/transaction';
import { FormField, inputClass } from './FormField';
import { TypeField } from './TypeField';

export const FIELD_IDS: Record<Field, string> = {
  type: 'tipo',
  description: 'descricao',
  amount: 'valor',
  category: 'categoria',
  date: 'data',
};

const FIELD_ORDER: Field[] = ['type', 'description', 'amount', 'category', 'date'];

interface TransactionFormProps {
  values: FormValues;
  errors: FormErrors;
  submitting: boolean;
  onChange: (field: Field, value: string) => void;
  onSubmit: (event: FormEvent) => void;
}

function useFocusFirstError(errors: FormErrors) {
  const pending = useRef(false);
  useEffect(() => {
    if (!pending.current) return;
    pending.current = false;
    const first = FIELD_ORDER.find((field) => errors[field]);
    if (first) document.getElementById(FIELD_IDS[first])?.focus();
  }, [errors]);
  return pending;
}

export function TransactionForm({ values, errors, submitting, onChange, onSubmit }: TransactionFormProps) {
  const focusPendingRef = useFocusFirstError(errors);

  const handleSubmit = (event: FormEvent) => {
    focusPendingRef.current = true;
    onSubmit(event);
  };

  return (
    <form noValidate onSubmit={handleSubmit} aria-labelledby="form-titulo" className="space-y-4">
      <h2 id="form-titulo" className="text-lg font-bold">
        Novo lançamento
      </h2>
      <TypeField value={values.type} error={errors.type} onChange={(value) => onChange('type', value)} />
      <FormField id={FIELD_IDS.description} label="Descrição" error={errors.description}>
        {(aria) => (
          <input
            {...aria}
            type="text"
            autoComplete="off"
            maxLength={MAX_DESCRIPTION_LENGTH + 20}
            value={values.description}
            onChange={(event) => onChange('description', event.target.value)}
            className={inputClass}
          />
        )}
      </FormField>
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField id={FIELD_IDS.amount} label="Valor (R$)" error={errors.amount}>
          {(aria) => (
            <input
              {...aria}
              type="text"
              inputMode="decimal"
              placeholder="0,00"
              value={values.amount}
              onChange={(event) => onChange('amount', event.target.value)}
              className={`${inputClass} tabular-nums`}
            />
          )}
        </FormField>
        <FormField id={FIELD_IDS.date} label="Data" error={errors.date}>
          {(aria) => (
            <input
              {...aria}
              type="date"
              value={values.date}
              onChange={(event) => onChange('date', event.target.value)}
              className={inputClass}
            />
          )}
        </FormField>
      </div>
      <FormField id={FIELD_IDS.category} label="Categoria" error={errors.category}>
        {(aria) => (
          <select
            {...aria}
            value={values.category}
            onChange={(event) => onChange('category', event.target.value)}
            className={inputClass}
          >
            <option value="">Selecione…</option>
            {CATEGORIES.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        )}
      </FormField>
      <button
        type="submit"
        disabled={submitting}
        className="w-full rounded-md bg-accent px-4 py-3 font-semibold text-white hover:bg-accent-strong disabled:opacity-60"
      >
        {submitting ? 'Salvando…' : 'Adicionar lançamento'}
      </button>
    </form>
  );
}
