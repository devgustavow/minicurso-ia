import type { MonthlySummary } from '../types/transaction';
import { formatCents } from '../utils/money';

interface SummaryCardsProps {
  summary: MonthlySummary;
}

export function SummaryCards({ summary }: SummaryCardsProps) {
  const negative = summary.balanceCents < 0;
  return (
    <section aria-labelledby="resumo-titulo">
      <h2 id="resumo-titulo" className="sr-only">
        Resumo do mês
      </h2>
      <dl className="grid gap-4 sm:grid-cols-[1.4fr_1fr_1fr]">
        <div className="rounded-lg bg-accent p-5 text-white sm:row-span-1">
          <dt className="text-sm font-semibold text-white/85">Saldo do mês</dt>
          <dd className="mt-1 text-4xl font-bold tracking-tight tabular-nums" data-testid="saldo">
            {formatCents(summary.balanceCents)}
          </dd>
          <dd className="mt-1 text-sm font-medium text-white/90">
            {negative ? 'Saldo negativo: as despesas superam as receitas.' : 'Receitas menos despesas.'}
          </dd>
        </div>
        <div className="rounded-lg border border-line bg-sheet p-5">
          <dt className="text-sm font-semibold text-muted">Receitas</dt>
          <dd className="mt-1 text-2xl font-bold text-income tabular-nums" data-testid="receitas">
            {formatCents(summary.incomeCents)}
          </dd>
        </div>
        <div className="rounded-lg border border-line bg-sheet p-5">
          <dt className="text-sm font-semibold text-muted">Despesas</dt>
          <dd className="mt-1 text-2xl font-bold text-expense tabular-nums" data-testid="despesas">
            {formatCents(summary.expenseCents)}
          </dd>
        </div>
      </dl>
    </section>
  );
}
