import type { StatusNotice } from '../types/transaction';

interface StatusMessageProps {
  status: StatusNotice | null;
}

export function StatusMessage({ status }: StatusMessageProps) {
  return (
    <>
      <div role="status" aria-live="polite">
        {status?.kind === 'success' && (
          <p className="rounded-md bg-income-soft p-3 font-semibold text-income">{status.message}</p>
        )}
      </div>
      {status?.kind === 'error' && (
        <p role="alert" className="rounded-md bg-expense-soft p-3 font-semibold text-expense">
          {status.message}
        </p>
      )}
    </>
  );
}
