import { TYPE_LABELS, type Transaction } from '../types/transaction';
import { formatDate } from '../utils/date';
import { formatCents } from '../utils/money';

interface TransactionListProps {
  transactions: Transaction[];
  loading: boolean;
  error: string | null;
}

const TYPE_STYLE = {
  income: 'bg-income-soft text-income',
  expense: 'bg-expense-soft text-expense',
} as const;

function TransactionItem({ transaction }: { transaction: Transaction }) {
  const { type, description, category, date, amountCents } = transaction;
  return (
    <li className="grid grid-cols-[1fr_auto] gap-x-4 gap-y-1 py-3">
      <p className="min-w-0 break-words font-semibold">{description}</p>
      <p className={`text-right font-bold tabular-nums ${type === 'income' ? 'text-income' : 'text-expense'}`}>
        {formatCents(amountCents)}
      </p>
      <p className="text-sm text-muted">
        <span className={`mr-2 rounded px-1.5 py-0.5 text-xs font-bold ${TYPE_STYLE[type]}`}>{TYPE_LABELS[type]}</span>
        {category}
      </p>
      <p className="text-right text-sm text-muted tabular-nums">{formatDate(date)}</p>
    </li>
  );
}

function ListBody({ transactions, loading, error }: TransactionListProps) {
  if (error) {
    return (
      <p role="alert" className="rounded-md bg-expense-soft p-3 font-medium text-expense">
        {error}
      </p>
    );
  }
  if (loading) {
    return <p className="py-6 text-center text-muted">Carregando lançamentos…</p>;
  }
  if (transactions.length === 0) {
    return <p className="py-6 text-center text-muted">Nenhum lançamento neste mês.</p>;
  }
  return (
    <ul className="divide-y divide-line" aria-label="Lançamentos">
      {transactions.map((transaction) => (
        <TransactionItem key={transaction.id} transaction={transaction} />
      ))}
    </ul>
  );
}

export function TransactionList(props: TransactionListProps) {
  return (
    <section aria-labelledby="lista-titulo" aria-busy={props.loading}>
      <h2 id="lista-titulo" className="text-lg font-bold">
        Lançamentos do mês
      </h2>
      <div className="mt-2">
        <ListBody {...props} />
      </div>
    </section>
  );
}
