import { act, renderHook, waitFor } from '@testing-library/react';
import * as api from '../services/transactionsApi';
import { SUCCESS_MESSAGE, initialFormValues, useTransactionForm } from './useTransactionForm';
import { useMonthlyTransactions } from './useMonthlyTransactions';

const report = { month: '2026-10', transactions: [], summary: { incomeCents: 0, expenseCents: 0, balanceCents: 0 } };
const created = { id: 1, type: 'income', description: 'Salário', amountCents: 100, category: 'Salário', date: '2026-09-01', createdAt: '' } as const;

afterEach(() => {
  vi.restoreAllMocks();
});

describe('useMonthlyTransactions', () => {
  it('carrega o mês e recarrega sob demanda', async () => {
    const spy = vi.spyOn(api, 'fetchMonthly').mockResolvedValue(report);
    const { result } = renderHook(() => useMonthlyTransactions('2026-10'));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.report).toEqual(report);
    act(() => result.current.reload());
    await waitFor(() => expect(spy).toHaveBeenCalledTimes(2));
  });

  it('expõe mensagem de erro quando a API falha', async () => {
    vi.spyOn(api, 'fetchMonthly').mockRejectedValue(new api.ApiConnectionError());
    const { result } = renderHook(() => useMonthlyTransactions('2026-10'));
    await waitFor(() => expect(result.current.error).toBe(api.CONNECTION_ERROR_MESSAGE));
    expect(result.current.report).toBeNull();
  });

  it('usa a mensagem padrão para erros desconhecidos', async () => {
    vi.spyOn(api, 'fetchMonthly').mockRejectedValue(new Error('x'));
    const { result } = renderHook(() => useMonthlyTransactions('2026-10'));
    await waitFor(() => expect(result.current.error).toBe(api.CONNECTION_ERROR_MESSAGE));
  });
});

describe('useTransactionForm', () => {
  function fill(result: { current: ReturnType<typeof useTransactionForm> }) {
    act(() => {
      result.current.setField('type', 'income');
      result.current.setField('description', 'Salário');
      result.current.setField('amount', '1,00');
      result.current.setField('category', 'Salário');
      result.current.setField('date', '2026-09-01');
    });
  }

  it('inicia com a data de hoje e campos vazios', () => {
    expect(initialFormValues(new Date(2026, 9, 15))).toEqual({ type: '', description: '', amount: '', category: '', date: '2026-10-15' });
  });

  it('não envia quando há erros de validação', async () => {
    const spy = vi.spyOn(api, 'createTransaction');
    const { result } = renderHook(() => useTransactionForm(vi.fn()));
    await act(() => result.current.submit());
    expect(result.current.errors.type).toBe('Selecione o tipo.');
    expect(spy).not.toHaveBeenCalled();
  });

  it('envia, limpa o formulário e avisa sucesso', async () => {
    vi.spyOn(api, 'createTransaction').mockResolvedValue(created);
    const onCreated = vi.fn();
    const { result } = renderHook(() => useTransactionForm(onCreated));
    fill(result);
    await act(() => result.current.submit());
    expect(onCreated).toHaveBeenCalledWith(created);
    expect(result.current.status).toEqual({ kind: 'success', message: SUCCESS_MESSAGE });
    expect(result.current.values.description).toBe('');
  });

  it('mapeia erros de validação da API para os campos', async () => {
    vi.spyOn(api, 'createTransaction').mockRejectedValue(new api.ApiValidationError({ amountCents: 'Valor inválido.', extra: 'x' }));
    const { result } = renderHook(() => useTransactionForm(vi.fn()));
    fill(result);
    await act(() => result.current.submit());
    expect(result.current.errors).toEqual({ amount: 'Valor inválido.' });
  });

  it('mantém os valores e mostra erro de comunicação', async () => {
    vi.spyOn(api, 'createTransaction').mockRejectedValue(new api.ApiConnectionError());
    const { result } = renderHook(() => useTransactionForm(vi.fn()));
    fill(result);
    await act(() => result.current.submit());
    expect(result.current.status).toEqual({ kind: 'error', message: api.CONNECTION_ERROR_MESSAGE });
    expect(result.current.values.description).toBe('Salário');
  });
});
