import { useCallback, useEffect, useState } from 'react';
import { ApiConnectionError, CONNECTION_ERROR_MESSAGE, fetchMonthly } from '../services/transactionsApi';
import type { MonthlyReport } from '../types/transaction';

export interface MonthlyTransactionsState {
  report: MonthlyReport | null;
  loading: boolean;
  error: string | null;
  reload: () => void;
}

interface LoadedState {
  key: string;
  report: MonthlyReport | null;
  error: string | null;
}

export function useMonthlyTransactions(month: string): MonthlyTransactionsState {
  const [version, setVersion] = useState(0);
  const [loaded, setLoaded] = useState<LoadedState | null>(null);
  const key = `${month}#${version}`;

  useEffect(() => {
    let active = true;
    fetchMonthly(month)
      .then((report) => {
        if (active) setLoaded({ key, report, error: null });
      })
      .catch((cause: unknown) => {
        const error = cause instanceof ApiConnectionError ? cause.message : CONNECTION_ERROR_MESSAGE;
        if (active) setLoaded({ key, report: null, error });
      });
    return () => {
      active = false;
    };
  }, [month, key]);

  const reload = useCallback(() => setVersion((value) => value + 1), []);
  const loading = loaded?.key !== key;
  const isSameMonth = loaded?.report?.month === month;

  return {
    report: isSameMonth || !loading ? (loaded?.report ?? null) : null,
    loading,
    error: loading ? null : (loaded?.error ?? null),
    reload,
  };
}
