import { useCallback, useState, type FormEvent } from 'react';
import {
  ApiValidationError,
  CONNECTION_ERROR_MESSAGE,
  createTransaction,
} from '../services/transactionsApi';
import type { FormErrors, FormField, FormValues, StatusNotice, Transaction } from '../types/transaction';
import { todayISO } from '../utils/date';
import { validateForm } from '../utils/validation';

export const SUCCESS_MESSAGE = 'Lançamento cadastrado com sucesso.';

const API_FIELD_MAP: Record<string, FormField> = {
  type: 'type',
  description: 'description',
  amountCents: 'amount',
  category: 'category',
  date: 'date',
};

export function initialFormValues(now: Date = new Date()): FormValues {
  return { type: '', description: '', amount: '', category: '', date: todayISO(now) };
}

function mapApiErrors(details: Record<string, string>): FormErrors {
  const errors: FormErrors = {};
  for (const [field, message] of Object.entries(details)) {
    const target = API_FIELD_MAP[field];
    if (target) errors[target] = message;
  }
  return errors;
}

export interface TransactionFormState {
  values: FormValues;
  errors: FormErrors;
  submitting: boolean;
  status: StatusNotice | null;
  setField: (field: FormField, value: string) => void;
  submit: (event?: FormEvent) => Promise<void>;
}

export function useTransactionForm(onCreated: (transaction: Transaction) => void): TransactionFormState {
  const [values, setValues] = useState<FormValues>(() => initialFormValues());
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [status, setStatus] = useState<StatusNotice | null>(null);

  const setField = useCallback((field: FormField, value: string) => {
    setValues((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
  }, []);

  const submit = async (event?: FormEvent): Promise<void> => {
    event?.preventDefault();
    setStatus(null);
    const validation = validateForm(values);
    if (!validation.ok) {
      setErrors(validation.errors);
      return;
    }
    setSubmitting(true);
    try {
      const created = await createTransaction(validation.payload);
      setValues(initialFormValues());
      setErrors({});
      setStatus({ kind: 'success', message: SUCCESS_MESSAGE });
      onCreated(created);
    } catch (cause) {
      if (cause instanceof ApiValidationError) {
        setErrors(mapApiErrors(cause.details));
      } else {
        setStatus({ kind: 'error', message: CONNECTION_ERROR_MESSAGE });
      }
    } finally {
      setSubmitting(false);
    }
  };

  return { values, errors, submitting, status, setField, submit };
}
