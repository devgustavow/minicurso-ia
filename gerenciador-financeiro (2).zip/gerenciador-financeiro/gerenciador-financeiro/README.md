# Gerenciador Financeiro Pessoal

Registre receitas e despesas e acompanhe o total de entradas, saídas e o saldo de cada mês.

## Como rodar

Requer Node.js 22 ou superior.

```bash
npm install
cp backend/.env.example backend/.env   # opcional: ajusta porta e caminho do banco
npm run dev
```

Abra http://localhost:5173. A API sobe em http://localhost:3000 e os dados ficam em `backend/data/finance.db`.

## Testes

```bash
npm run lint
npm run typecheck
npm run test:coverage
npx playwright install chromium   # uma vez
npm run e2e
```

## Documentação

- `AGENTS.md` e `.agents/rules/`: padrões do projeto
- `tasks/prd-gerenciador-financeiro/`: PRD, TechSpec, tarefas, revisão de código, QA e evidências
